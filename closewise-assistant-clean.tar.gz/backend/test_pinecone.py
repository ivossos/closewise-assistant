"""
Pinecone Integration Test for CloseWise Assistant

This script tests the Pinecone connection and creates the required index
for the Oracle EPM knowledge base.
"""

import os
from pinecone import Pinecone, ServerlessSpec
from api_config import config
import time


def test_pinecone_connection():
    """Test Pinecone API connection."""
    try:
        print("Testing Pinecone connection...")
        
        # Initialize Pinecone
        pc = Pinecone(api_key=config.pinecone_api_key)
        
        # List existing indexes
        indexes = pc.list_indexes()
        print(f"✅ Connected to Pinecone successfully!")
        print(f"Existing indexes: {[idx.name for idx in indexes]}")
        
        return pc
        
    except Exception as e:
        print(f"❌ Pinecone connection failed: {e}")
        return None


def create_epm_index(pc):
    """Create the CloseWise EPM index if it doesn't exist."""
    try:
        index_name = config.pinecone_index_name
        
        # Check if index already exists
        existing_indexes = [idx.name for idx in pc.list_indexes()]
        
        if index_name in existing_indexes:
            print(f"✅ Index '{index_name}' already exists")
            return pc.Index(index_name)
        
        print(f"Creating new index: {index_name}")
        
        # Create index with serverless spec
        pc.create_index(
            name=index_name,
            dimension=config.embedding_dimensions,  # text-embedding-3-large dimensions
            metric='cosine',
            spec=ServerlessSpec(
                cloud='aws',
                region='us-east-1'
            )
        )
        
        # Wait for index to be ready
        print("Waiting for index to be ready...")
        while not pc.describe_index(index_name).status['ready']:
            time.sleep(1)
        
        print(f"✅ Index '{index_name}' created successfully!")
        
        return pc.Index(index_name)
        
    except Exception as e:
        print(f"❌ Failed to create index: {e}")
        return None


def test_index_operations(index):
    """Test basic index operations."""
    try:
        print("Testing index operations...")
        
        # Get index stats
        stats = index.describe_index_stats()
        print(f"Index stats: {stats}")
        
        # Test upsert with sample data
        test_vectors = [
            {
                "id": "test-1",
                "values": [0.1] * config.embedding_dimensions,
                "metadata": {
                    "text": "Test Oracle EPM document",
                    "module": "fccs",
                    "source": "test"
                }
            }
        ]
        
        print("Upserting test vector...")
        index.upsert(vectors=test_vectors)
        
        # Wait a moment for the upsert to process
        time.sleep(2)
        
        # Test query
        print("Testing query...")
        query_response = index.query(
            vector=[0.1] * config.embedding_dimensions,
            top_k=1,
            include_metadata=True
        )
        
        print(f"Query response: {query_response}")
        
        # Clean up test data
        print("Cleaning up test data...")
        index.delete(ids=["test-1"])
        
        print("✅ Index operations test successful!")
        return True
        
    except Exception as e:
        print(f"❌ Index operations test failed: {e}")
        return False


def main():
    """Main test function."""
    print("CloseWise Assistant - Pinecone Integration Test")
    print("=" * 50)
    
    # Test connection
    pc = test_pinecone_connection()
    if not pc:
        return False
    
    # Create/get index
    index = create_epm_index(pc)
    if not index:
        return False
    
    # Test operations
    success = test_index_operations(index)
    
    if success:
        print("\n🎉 Pinecone integration fully operational!")
        print(f"Index: {config.pinecone_index_name}")
        print(f"Dimensions: {config.embedding_dimensions}")
        print(f"Metric: cosine")
        print("Ready for EPM content ingestion!")
    else:
        print("\n❌ Pinecone integration test failed")
    
    return success


if __name__ == "__main__":
    main()

