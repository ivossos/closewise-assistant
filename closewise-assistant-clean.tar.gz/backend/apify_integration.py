"""
Advanced Apify Integration Components

This module provides advanced integration capabilities with Apify platform,
including the official Pinecone integration and custom workflow orchestration.
"""

import os
import json
import time
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, asdict
from datetime import datetime

from apify_client import ApifyClient


@dataclass
class PineconeIntegrationConfig:
    """Configuration for Apify-Pinecone integration."""
    apify_token: str
    pinecone_api_key: str
    pinecone_index_name: str
    embedding_provider: str = "OpenAI"  # OpenAI, Cohere, HuggingFace
    embedding_api_key: str = ""
    embedding_model: str = "text-embedding-3-large"
    chunk_size: int = 1000
    chunk_overlap: int = 200
    perform_chunking: bool = True
    data_updates_strategy: str = "deltaUpdates"  # add, upsert, deltaUpdates
    namespace: str = ""
    
    def to_actor_input(self, dataset_id: str) -> Dict[str, Any]:
        """Convert configuration to Apify Actor input format."""
        return {
            "datasetId": dataset_id,
            "datasetFields": ["text"],
            "metadataDatasetFields": {
                "title": "title",
                "url": "url",
                "contentType": "content_type",
                "extractionTimestamp": "extraction_timestamp"
            },
            "pineconeApiKey": self.pinecone_api_key,
            "pineconeIndexName": self.pinecone_index_name,
            "pineconeNamespace": self.namespace,
            "embeddingsProvider": self.embedding_provider,
            "embeddingsApiKey": self.embedding_api_key,
            "embeddingsConfig": {
                "model": self.embedding_model
            },
            "performChunking": self.perform_chunking,
            "chunkSize": self.chunk_size,
            "chunkOverlap": self.chunk_overlap,
            "dataUpdatesStrategy": self.data_updates_strategy
        }


class ApifyPineconeIntegration:
    """Manages the official Apify-Pinecone integration workflow."""
    
    def __init__(self, config: PineconeIntegrationConfig):
        """Initialize the integration with configuration."""
        self.config = config
        self.client = ApifyClient(config.apify_token)
        self.integration_actor_id = "apify/pinecone-integration"
        
    def run_extraction_and_storage_pipeline(self, 
                                          source_urls: List[str],
                                          extraction_actor_id: str = "apify/website-content-crawler") -> Dict[str, Any]:
        """
        Run the complete pipeline from extraction to vector storage.
        
        Args:
            source_urls: URLs to extract content from
            extraction_actor_id: Actor to use for content extraction
            
        Returns:
            Dictionary with pipeline results and metadata
        """
        print("=== Starting Apify-Pinecone Pipeline ===")
        
        # Step 1: Extract content using Website Content Crawler
        print(f"Step 1: Extracting content from {len(source_urls)} URLs...")
        extraction_result = self._run_content_extraction(source_urls, extraction_actor_id)
        
        if not extraction_result["success"]:
            return {"success": False, "error": "Content extraction failed", "details": extraction_result}
        
        dataset_id = extraction_result["dataset_id"]
        extracted_items = extraction_result["item_count"]
        
        print(f"✓ Extracted {extracted_items} items to dataset {dataset_id}")
        
        # Step 2: Process and store in Pinecone
        print("Step 2: Processing content and storing in Pinecone...")
        storage_result = self._run_pinecone_integration(dataset_id)
        
        if not storage_result["success"]:
            return {"success": False, "error": "Pinecone storage failed", "details": storage_result}
        
        print(f"✓ Successfully processed and stored vectors in Pinecone")
        
        # Step 3: Compile results
        pipeline_result = {
            "success": True,
            "extraction": extraction_result,
            "storage": storage_result,
            "summary": {
                "source_urls": len(source_urls),
                "extracted_items": extracted_items,
                "processed_chunks": storage_result.get("processed_chunks", 0),
                "stored_vectors": storage_result.get("stored_vectors", 0),
                "pipeline_duration": storage_result.get("total_duration", 0)
            }
        }
        
        print("=== Pipeline Completed Successfully ===")
        return pipeline_result
    
    def _run_content_extraction(self, urls: List[str], actor_id: str) -> Dict[str, Any]:
        """Run content extraction using specified Actor."""
        try:
            # Configure extraction input
            extraction_input = {
                "startUrls": [{"url": url} for url in urls],
                "maxCrawlPages": 100,
                "maxCrawlDepth": 3,
                "htmlTransformer": "readabilityExtractor",
                "removeElementsCssSelector": "nav, footer, .navigation, .sidebar, .ads",
                "saveMarkdown": True,
                "saveHtml": False,
                "maxFileSize": 1048576
            }
            
            # Run the extraction Actor
            run = self.client.actor(actor_id).call(run_input=extraction_input)
            
            # Get dataset information
            dataset_id = run["defaultDatasetId"]
            dataset_items = list(self.client.dataset(dataset_id).iterate_items())
            
            return {
                "success": True,
                "dataset_id": dataset_id,
                "run_id": run["id"],
                "item_count": len(dataset_items),
                "duration": run.get("stats", {}).get("runTimeSecs", 0)
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "dataset_id": None
            }
    
    def _run_pinecone_integration(self, dataset_id: str) -> Dict[str, Any]:
        """Run the Pinecone integration Actor."""
        try:
            # Configure integration input
            integration_input = self.config.to_actor_input(dataset_id)
            
            # Run the integration Actor
            run = self.client.actor(self.integration_actor_id).call(run_input=integration_input)
            
            # Get run statistics
            stats = run.get("stats", {})
            
            return {
                "success": True,
                "run_id": run["id"],
                "duration": stats.get("runTimeSecs", 0),
                "processed_chunks": stats.get("outputDatasetItems", 0),
                "stored_vectors": stats.get("outputDatasetItems", 0),  # Approximate
                "total_duration": stats.get("runTimeSecs", 0)
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "run_id": None
            }
    
    def monitor_run_progress(self, run_id: str) -> Dict[str, Any]:
        """Monitor the progress of a running Actor."""
        try:
            run_info = self.client.run(run_id).get()
            
            return {
                "status": run_info["status"],
                "started_at": run_info["startedAt"],
                "finished_at": run_info.get("finishedAt"),
                "duration": run_info.get("stats", {}).get("runTimeSecs", 0),
                "memory_usage": run_info.get("stats", {}).get("memoryUsageMb", 0),
                "compute_units": run_info.get("stats", {}).get("computeUnits", 0)
            }
            
        except Exception as e:
            return {"error": str(e)}
    
    def get_dataset_preview(self, dataset_id: str, limit: int = 5) -> List[Dict[str, Any]]:
        """Get a preview of dataset items."""
        try:
            items = list(self.client.dataset(dataset_id).iterate_items(limit=limit))
            return items
        except Exception as e:
            print(f"Error getting dataset preview: {e}")
            return []


class WorkflowOrchestrator:
    """Orchestrates complex multi-step workflows with Apify and Pinecone."""
    
    def __init__(self, apify_token: str):
        """Initialize the orchestrator."""
        self.client = ApifyClient(apify_token)
        self.workflows = {}
        
    def create_scheduled_workflow(self, 
                                workflow_name: str,
                                source_configs: List[Dict[str, Any]],
                                pinecone_config: PineconeIntegrationConfig,
                                schedule_cron: str = "0 2 * * *") -> Dict[str, Any]:
        """
        Create a scheduled workflow for regular content updates.
        
        Args:
            workflow_name: Name for the workflow
            source_configs: List of source configurations
            pinecone_config: Pinecone integration configuration
            schedule_cron: Cron expression for scheduling
            
        Returns:
            Workflow configuration and schedule information
        """
        workflow_config = {
            "name": workflow_name,
            "sources": source_configs,
            "pinecone_config": asdict(pinecone_config),
            "schedule": schedule_cron,
            "created_at": datetime.now().isoformat(),
            "status": "active"
        }
        
        self.workflows[workflow_name] = workflow_config
        
        print(f"Created scheduled workflow: {workflow_name}")
        print(f"Schedule: {schedule_cron}")
        print(f"Sources: {len(source_configs)} configured")
        
        return workflow_config
    
    def run_incremental_update(self, 
                             workflow_name: str,
                             force_full_refresh: bool = False) -> Dict[str, Any]:
        """
        Run an incremental update for a configured workflow.
        
        Args:
            workflow_name: Name of the workflow to run
            force_full_refresh: Whether to force a full refresh
            
        Returns:
            Update results and statistics
        """
        if workflow_name not in self.workflows:
            return {"success": False, "error": f"Workflow {workflow_name} not found"}
        
        workflow = self.workflows[workflow_name]
        
        print(f"Running incremental update for workflow: {workflow_name}")
        
        # Configure update strategy
        update_strategy = "add" if force_full_refresh else "deltaUpdates"
        
        # Process each source configuration
        results = []
        for source_config in workflow["sources"]:
            source_result = self._process_source_update(source_config, update_strategy)
            results.append(source_result)
        
        # Compile overall results
        total_items = sum(r.get("item_count", 0) for r in results)
        successful_sources = sum(1 for r in results if r.get("success", False))
        
        update_result = {
            "success": successful_sources > 0,
            "workflow_name": workflow_name,
            "update_strategy": update_strategy,
            "sources_processed": len(results),
            "successful_sources": successful_sources,
            "total_items_processed": total_items,
            "source_results": results,
            "timestamp": datetime.now().isoformat()
        }
        
        print(f"Update completed: {successful_sources}/{len(results)} sources successful")
        print(f"Total items processed: {total_items}")
        
        return update_result
    
    def _process_source_update(self, source_config: Dict[str, Any], 
                             update_strategy: str) -> Dict[str, Any]:
        """Process updates for a single source configuration."""
        try:
            source_type = source_config.get("type", "website")
            urls = source_config.get("urls", [])
            
            if source_type == "website":
                return self._update_website_source(urls, update_strategy)
            elif source_type == "sitemap":
                return self._update_sitemap_source(source_config, update_strategy)
            elif source_type == "rss":
                return self._update_rss_source(source_config, update_strategy)
            else:
                return {"success": False, "error": f"Unknown source type: {source_type}"}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def _update_website_source(self, urls: List[str], update_strategy: str) -> Dict[str, Any]:
        """Update content from website URLs."""
        # This would implement website-specific update logic
        return {
            "success": True,
            "source_type": "website",
            "urls_processed": len(urls),
            "item_count": len(urls) * 5,  # Simulated
            "update_strategy": update_strategy
        }
    
    def _update_sitemap_source(self, config: Dict[str, Any], update_strategy: str) -> Dict[str, Any]:
        """Update content from sitemap."""
        # This would implement sitemap-specific update logic
        return {
            "success": True,
            "source_type": "sitemap",
            "sitemap_url": config.get("sitemap_url"),
            "item_count": 25,  # Simulated
            "update_strategy": update_strategy
        }
    
    def _update_rss_source(self, config: Dict[str, Any], update_strategy: str) -> Dict[str, Any]:
        """Update content from RSS feeds."""
        # This would implement RSS-specific update logic
        return {
            "success": True,
            "source_type": "rss",
            "feed_url": config.get("feed_url"),
            "item_count": 10,  # Simulated
            "update_strategy": update_strategy
        }


def create_sample_pinecone_config() -> PineconeIntegrationConfig:
    """Create a sample Pinecone integration configuration."""
    return PineconeIntegrationConfig(
        apify_token="your_apify_token_here",
        pinecone_api_key="your_pinecone_api_key_here",
        pinecone_index_name="knowledge-base",
        embedding_provider="OpenAI",
        embedding_api_key="your_openai_api_key_here",
        embedding_model="text-embedding-3-large",
        chunk_size=1000,
        chunk_overlap=200,
        perform_chunking=True,
        data_updates_strategy="deltaUpdates",
        namespace="documents"
    )


if __name__ == "__main__":
    print("Advanced Apify Integration Components")
    print("This module provides advanced integration capabilities with Apify and Pinecone.")
    print("Configure with your API tokens to enable full functionality.")

