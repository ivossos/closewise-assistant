"""
CloseWise Assistant Flask Backend API

This module provides the Flask backend API that integrates with the React frontend
and connects to the Apify-RAG-Pinecone pipeline.
"""

from flask import Flask, request, jsonify, session
from flask_cors import CORS
import uuid
import json
from datetime import datetime
from typing import Dict, List, Optional

from api_config import config
from closewise_backend import CloseWiseBackend
from epm_rag_processor import EPMContentProcessor


app = Flask(__name__)
app.secret_key = 'closewise-secret-key-change-in-production'
CORS(app)

# Initialize CloseWise backend
try:
    closewise = CloseWiseBackend(
        openai_api_key=config.openai_api_key,
        pinecone_api_key=config.pinecone_api_key,
        pinecone_index_name=config.pinecone_index_name
    )
    backend_available = True
except Exception as e:
    print(f"Warning: Backend initialization failed: {e}")
    print("Running in demo mode with simulated responses")
    closewise = None
    backend_available = False


@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    validation = config.validate_keys()
    return jsonify({
        "status": "healthy",
        "app_name": config.app_name,
        "version": config.app_version,
        "backend_available": backend_available,
        "api_keys_configured": validation,
        "demo_mode": not backend_available
    })


@app.route('/api/config', methods=['GET'])
def get_config():
    """Get application configuration."""
    return jsonify(config.get_config_summary())


@app.route('/api/chat', methods=['POST'])
def process_chat():
    """Process chat message."""
    try:
        data = request.get_json()
        
        # Get or create session ID
        session_id = data.get('session_id') or str(uuid.uuid4())
        message = data.get('message', '').strip()
        language = data.get('language', config.default_language)
        
        if not message:
            return jsonify({"error": "Message is required"}), 400
        
        # Process message
        if backend_available and closewise:
            response = closewise.process_chat_message(session_id, message, language)
            return jsonify({
                "success": True,
                "session_id": session_id,
                "message": response.to_dict()
            })
        else:
            # Demo mode response
            demo_response = generate_demo_response(message, language)
            return jsonify({
                "success": True,
                "session_id": session_id,
                "message": demo_response,
                "demo_mode": True
            })
            
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/chat/history/<session_id>', methods=['GET'])
def get_chat_history(session_id):
    """Get chat history for a session."""
    try:
        if backend_available and closewise and session_id in closewise.chat_sessions:
            messages = [msg.to_dict() for msg in closewise.chat_sessions[session_id]]
            return jsonify({
                "success": True,
                "session_id": session_id,
                "messages": messages
            })
        else:
            return jsonify({
                "success": True,
                "session_id": session_id,
                "messages": [],
                "demo_mode": True
            })
            
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/upload', methods=['POST'])
def upload_pdf():
    """Upload and process PDF files."""
    try:
        if 'file' not in request.files:
            return jsonify({"error": "No file provided"}), 400
        
        file = request.files['file']
        session_id = request.form.get('session_id', str(uuid.uuid4()))
        
        if file.filename == '':
            return jsonify({"error": "No file selected"}), 400
        
        if not file.filename.lower().endswith('.pdf'):
            return jsonify({"error": "Only PDF files are supported"}), 400
        
        # Save uploaded file
        filename = f"upload_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{file.filename}"
        file_path = f"/tmp/{filename}"
        file.save(file_path)
        
        # Process file
        if backend_available and closewise:
            result = closewise.process_pdf_upload(file_path, session_id)
        else:
            # Demo mode response
            result = {
                "success": True,
                "message": "PDF processado com sucesso (modo demo)",
                "pages_processed": 15,
                "chunks_created": 45,
                "module_detected": "fccs",
                "demo_mode": True
            }
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/knowledge-base/stats', methods=['GET'])
def get_knowledge_base_stats():
    """Get knowledge base statistics."""
    try:
        if backend_available and closewise:
            stats = closewise.get_knowledge_base_stats()
        else:
            # Demo mode stats
            stats = {
                "total_documents": 1247,
                "total_chunks": 8934,
                "modules": {
                    "fccs": 2156,
                    "epbcs": 2834,
                    "essbase": 1567,
                    "arcs": 1234,
                    "workforce": 892,
                    "other": 251
                },
                "languages": {
                    "portuguese": 5234,
                    "english": 3700
                },
                "last_updated": datetime.now().isoformat(),
                "demo_mode": True
            }
        
        return jsonify(stats)
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/suggestions', methods=['GET'])
def get_suggestions():
    """Get suggested questions."""
    try:
        module = request.args.get('module')
        
        if backend_available and closewise:
            suggestions = closewise.get_suggested_questions(module)
        else:
            # Demo mode suggestions
            if module == "fccs":
                suggestions = [
                    "Como resolver erros de tradução de moeda no FCCS?",
                    "Quais são os passos para configurar eliminações?",
                    "Como executar o processo de consolidação?",
                    "Como configurar regras de conversão?"
                ]
            elif module == "epbcs":
                suggestions = [
                    "Como criar uma nova dimensão no Planning?",
                    "Como configurar formulários de entrada de dados?",
                    "Como criar regras de negócio?",
                    "Como configurar aprovações de workflow?"
                ]
            else:
                suggestions = [
                    "Como integrar FCCS com EPBCS?",
                    "Quais são as melhores práticas para backup?",
                    "Como configurar segurança e permissões?",
                    "Como otimizar performance do Essbase?"
                ]
        
        return jsonify({
            "success": True,
            "module": module,
            "suggestions": suggestions,
            "demo_mode": not backend_available
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/modules', methods=['GET'])
def get_epm_modules():
    """Get EPM module information."""
    modules = [
        {
            "id": "fccs",
            "name": "Financial Consolidation and Close",
            "description": "Consolidação financeira e processos de fechamento",
            "features": ["Eliminações", "Tradução de moeda", "Workflow de fechamento"],
            "color": "blue"
        },
        {
            "id": "epbcs",
            "name": "Enterprise Planning and Budgeting",
            "description": "Planejamento empresarial e orçamento",
            "features": ["Dimensões", "Formulários", "Regras de negócio"],
            "color": "green"
        },
        {
            "id": "essbase",
            "name": "Essbase Analytics",
            "description": "Analytics e processamento multidimensional",
            "features": ["Calc Scripts", "Outline", "Performance"],
            "color": "yellow"
        },
        {
            "id": "arcs",
            "name": "Account Reconciliation",
            "description": "Reconciliação de contas",
            "features": ["Reconciliações", "Certificação", "Workflow"],
            "color": "purple"
        },
        {
            "id": "workforce",
            "name": "Workforce Planning",
            "description": "Planejamento de força de trabalho",
            "features": ["Previsão salarial", "Headcount", "Benefícios"],
            "color": "pink"
        }
    ]
    
    return jsonify({
        "success": True,
        "modules": modules
    })


def generate_demo_response(message: str, language: str = "pt") -> Dict:
    """Generate demo response when backend is not available."""
    message_lower = message.lower()
    
    response = {
        "id": f"demo_{datetime.now().timestamp()}",
        "role": "assistant",
        "timestamp": datetime.now().isoformat(),
        "confidence": 0.85,
        "sources": [],
        "demo_mode": True
    }
    
    if any(word in message_lower for word in ["fccs", "consolidation", "consolidação"]):
        if language == "pt":
            response["content"] = """🔧 **Modo Demo - FCCS**

Com base na documentação do FCCS, posso ajudá-lo com questões de consolidação financeira.

**Para resolver problemas de consolidação:**
1. Verifique se todos os dados foram carregados corretamente
2. Confirme as regras de tradução de moeda
3. Revise as eliminações intercompanhia
4. Execute o processo de consolidação

*Nota: Esta é uma resposta simulada. Configure as chaves de API para respostas completas.*"""
        response["module"] = "fccs"
        response["sources"] = [
            {
                "title": "FCCS Consolidation Process Guide (Demo)",
                "url": "https://docs.oracle.com/en/cloud/saas/financial-consolidation-cloud/",
                "confidence": 0.92
            }
        ]
    
    elif any(word in message_lower for word in ["planning", "epbcs", "planejamento"]):
        if language == "pt":
            response["content"] = """📊 **Modo Demo - EPBCS**

Sobre o Planning and Budgeting Cloud Service (EPBCS):

**Para configurar dimensões:**
1. Acesse Application > Overview > Dimensions
2. Selecione a dimensão desejada
3. Configure as propriedades e hierarquias
4. Salve as alterações

*Nota: Esta é uma resposta simulada. Configure as chaves de API para funcionalidade completa.*"""
        response["module"] = "epbcs"
        response["sources"] = [
            {
                "title": "Planning Dimension Configuration (Demo)",
                "url": "https://docs.oracle.com/en/cloud/saas/planning-budgeting-cloud/",
                "confidence": 0.87
            }
        ]
    
    else:
        if language == "pt":
            response["content"] = """👋 **CloseWise Assistant - Modo Demo**

Olá! Sou o assistente CloseWise para Oracle EPM Cloud.

**Posso ajudá-lo com:**
- 🏢 **FCCS** (Consolidação Financeira)
- 📈 **EPBCS** (Planejamento e Orçamento)
- ⚡ **Essbase** (Analytics)
- ✅ **ARCS** (Reconciliação de Contas)
- 👥 **Workforce Planning**

*Atualmente em modo demo. Configure as chaves de API (Apify + Pinecone) para funcionalidade completa com busca em tempo real na base de conhecimento Oracle EPM.*

Como posso ajudá-lo hoje?"""
        response["module"] = None
    
    return response


if __name__ == '__main__':
    print("Starting CloseWise Assistant Backend API")
    print("=" * 40)
    
    # Print configuration status
    summary = config.get_config_summary()
    print(f"App: {summary['app_name']} v{summary['app_version']}")
    print(f"Backend Available: {backend_available}")
    print(f"Demo Mode: {not backend_available}")
    
    if not backend_available:
        print("\nRunning in DEMO MODE")
        print("Configure API keys for full functionality:")
        missing = config.get_missing_keys()
        for key in missing:
            print(f"  - {key.upper()}")
    
    print(f"\nStarting server on http://localhost:5000")
    print("API Endpoints:")
    print("  GET  /api/health")
    print("  POST /api/chat")
    print("  POST /api/upload")
    print("  GET  /api/knowledge-base/stats")
    print("  GET  /api/suggestions")
    print("  GET  /api/modules")
    
    app.run(debug=True, host='0.0.0.0', port=5000)

