"""
CloseWise Assistant API Configuration

This file manages API keys and configuration for the CloseWise Assistant.
"""

import os
from typing import Dict, Optional
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


class APIConfig:
    """Manages API configuration for CloseWise Assistant."""
    
    def __init__(self):
        """Initialize API configuration."""
        # OpenAI API Key (provided by user)
        self.openai_api_key = "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"
        
        # Apify API Key (configured)
        self.apify_api_key = os.getenv("APIFY_API_KEY", "apify_api_GHVBSIUC5kTgBjs63vuZhTCmWcFbMf0Cvajt")
        
        # Pinecone API Key (configured)
        self.pinecone_api_key = os.getenv("PINECONE_API_KEY", "pcsk_68n5xL_Uk6TsffoKMz67KgZBC1VoscN6sPF8z4uj1FbRbDxBxds92gByeWVxc335YF39fD")
        
        # Pinecone Configuration
        self.pinecone_index_name = "closewise-epm"
        self.pinecone_environment = "us-east-1-aws"
        
        # Embedding Configuration
        self.embedding_model = "text-embedding-3-large"
        self.embedding_dimensions = 3072
        
        # RAG Configuration
        self.chunk_size = 1000
        self.chunk_overlap = 200
        self.max_chunks_per_query = 5
        
        # Language Configuration
        self.default_language = "pt"  # Portuguese primary
        self.supported_languages = ["pt", "en"]
        
        # CloseWise Configuration
        self.app_name = "CloseWise Assistant"
        self.app_version = "1.0.0"
        self.support_email = "support@closewise.com"
        self.website_url = "www.closewise.com"
    
    def validate_keys(self) -> Dict[str, bool]:
        """Validate that required API keys are configured."""
        return {
            "openai": bool(self.openai_api_key and self.openai_api_key.startswith("sk-")),
            "apify": bool(self.apify_api_key),
            "pinecone": bool(self.pinecone_api_key)
        }
    
    def get_missing_keys(self) -> list:
        """Get list of missing API keys."""
        validation = self.validate_keys()
        return [key for key, valid in validation.items() if not valid]
    
    def is_fully_configured(self) -> bool:
        """Check if all required API keys are configured."""
        return all(self.validate_keys().values())
    
    def get_config_summary(self) -> Dict[str, any]:
        """Get configuration summary for debugging."""
        validation = self.validate_keys()
        return {
            "app_name": self.app_name,
            "app_version": self.app_version,
            "api_keys_status": validation,
            "missing_keys": self.get_missing_keys(),
            "embedding_model": self.embedding_model,
            "pinecone_index": self.pinecone_index_name,
            "default_language": self.default_language,
            "chunk_size": self.chunk_size
        }


# Global configuration instance
config = APIConfig()


def setup_environment_variables():
    """Setup environment variables for API keys."""
    env_template = """
# CloseWise Assistant API Configuration
# Copy this to .env file and fill in your API keys

# OpenAI API Key (already configured)
OPENAI_API_KEY=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

# Apify API Key (get from https://console.apify.com/account/integrations)
APIFY_API_KEY=your_apify_token_here

# Pinecone API Key (get from https://app.pinecone.io/)
PINECONE_API_KEY=your_pinecone_api_key_here

# Optional: Override default configurations
PINECONE_INDEX_NAME=closewise-epm
PINECONE_ENVIRONMENT=us-east-1-aws
EMBEDDING_MODEL=text-embedding-3-large
DEFAULT_LANGUAGE=pt
"""
    return env_template


def get_api_setup_instructions():
    """Get instructions for setting up API keys."""
    return """
CloseWise Assistant API Setup Instructions
==========================================

1. OpenAI API Key ✅ (Already configured)
   - Status: Ready to use
   - Model: text-embedding-3-large
   - Usage: Embedding generation and chat responses

2. Apify API Key (Required for web scraping)
   - Get your token: https://console.apify.com/account/integrations
   - Free tier: 1,000 Actor runs per month
   - Paid plans: Starting at $49/month
   - Set environment variable: APIFY_API_KEY

3. Pinecone API Key (Required for vector storage)
   - Get your API key: https://app.pinecone.io/
   - Free tier: 1 index, 100K vectors
   - Paid plans: Starting at $70/month
   - Set environment variable: PINECONE_API_KEY

4. Create Pinecone Index:
   - Name: closewise-epm
   - Dimensions: 3072 (for text-embedding-3-large)
   - Metric: cosine
   - Cloud: AWS (us-east-1)

5. Environment Setup:
   - Create .env file in project root
   - Add your API keys
   - Restart the application

Cost Estimates (Monthly):
- OpenAI Embeddings: $10-50 (depending on usage)
- Apify Web Scraping: $49-200 (depending on volume)
- Pinecone Vector Storage: $70+ (depending on vectors)
- Total: ~$130-320/month for production use

Development Mode:
- The application can run in demo mode without Apify/Pinecone
- Uses simulated responses and sample data
- Perfect for testing and development
"""


if __name__ == "__main__":
    print("CloseWise Assistant API Configuration")
    print("=" * 40)
    
    # Print configuration summary
    summary = config.get_config_summary()
    print(f"App: {summary['app_name']} v{summary['app_version']}")
    print(f"Default Language: {summary['default_language']}")
    print(f"Embedding Model: {summary['embedding_model']}")
    print(f"Pinecone Index: {summary['pinecone_index']}")
    print()
    
    # Print API key status
    print("API Keys Status:")
    for key, status in summary['api_keys_status'].items():
        status_icon = "✅" if status else "❌"
        print(f"  {key.upper()}: {status_icon}")
    
    if summary['missing_keys']:
        print(f"\nMissing Keys: {', '.join(summary['missing_keys'])}")
        print("\nSetup Instructions:")
        print(get_api_setup_instructions())
    else:
        print("\n✅ All API keys configured!")
    
    print("\nEnvironment Template:")
    print(setup_environment_variables())

