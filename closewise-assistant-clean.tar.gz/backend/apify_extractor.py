"""
Apify Data Extraction Components for RAG Pipeline

This module provides components for extracting data from web sources using Apify,
preparing it for RAG processing and vector storage in Pinecone.
"""

import os
import json
import time
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime

from apify_client import ApifyClient


@dataclass
class ExtractionConfig:
    """Configuration for data extraction operations."""
    apify_token: str
    max_pages: int = 100
    max_depth: int = 3
    include_metadata: bool = True
    content_types: List[str] = None
    
    def __post_init__(self):
        if self.content_types is None:
            self.content_types = ['article', 'blog', 'documentation', 'news']


@dataclass
class ExtractedContent:
    """Represents extracted content ready for RAG processing."""
    url: str
    title: str
    text: str
    metadata: Dict[str, Any]
    extraction_timestamp: str
    content_type: str
    word_count: int
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format for JSON serialization."""
        return {
            'url': self.url,
            'title': self.title,
            'text': self.text,
            'metadata': self.metadata,
            'extraction_timestamp': self.extraction_timestamp,
            'content_type': self.content_type,
            'word_count': self.word_count
        }


class ApifyExtractor:
    """Main class for extracting data using Apify platform."""
    
    def __init__(self, config: ExtractionConfig):
        """Initialize the extractor with configuration."""
        self.config = config
        self.client = ApifyClient(config.apify_token)
        
    def extract_website_content(self, start_urls: List[str], 
                              actor_id: str = "apify/website-content-crawler") -> List[ExtractedContent]:
        """
        Extract content from websites using Apify's Website Content Crawler.
        
        Args:
            start_urls: List of URLs to start crawling from
            actor_id: Apify Actor ID to use for extraction
            
        Returns:
            List of ExtractedContent objects
        """
        print(f"Starting content extraction from {len(start_urls)} URLs...")
        
        # Configure the Actor input
        actor_input = {
            "startUrls": [{"url": url} for url in start_urls],
            "maxCrawlPages": self.config.max_pages,
            "maxCrawlDepth": self.config.max_depth,
            "includeUrlGlobs": [],
            "excludeUrlGlobs": ["**/*.pdf", "**/*.jpg", "**/*.png", "**/*.gif"],
            "htmlTransformer": "readabilityExtractor",
            "readabilityMinScore": 0.2,
            "removeElementsCssSelector": "nav, footer, .navigation, .sidebar, .ads",
            "clickElementsCssSelector": "",
            "waitForSelector": "",
            "scrollToBottom": False,
            "sessionPoolSize": 1,
            "maxSessionRotations": 10,
            "maxRequestRetries": 3,
            "requestTimeoutSecs": 60,
            "dynamicContentWaitSecs": 10,
            "maxScrollHeightPixels": 5000,
            "saveHtml": False,
            "saveMarkdown": True,
            "saveFiles": False,
            "maxFileSize": 1048576,
            "saveScreenshots": False
        }
        
        # Run the Actor
        print("Running Apify Actor...")
        run = self.client.actor(actor_id).call(run_input=actor_input)
        
        # Wait for completion and get results
        print("Waiting for extraction to complete...")
        dataset_items = list(self.client.dataset(run["defaultDatasetId"]).iterate_items())
        
        print(f"Extracted {len(dataset_items)} items")
        
        # Process and convert results
        extracted_content = []
        for item in dataset_items:
            content = self._process_extracted_item(item)
            if content:
                extracted_content.append(content)
                
        print(f"Processed {len(extracted_content)} valid content items")
        return extracted_content
    
    def extract_specific_sites(self, site_configs: List[Dict[str, Any]]) -> List[ExtractedContent]:
        """
        Extract content from specific sites using targeted Actors.
        
        Args:
            site_configs: List of site-specific configurations
            
        Returns:
            List of ExtractedContent objects
        """
        all_content = []
        
        for config in site_configs:
            site_type = config.get('type', 'generic')
            urls = config.get('urls', [])
            
            if site_type == 'news':
                content = self._extract_news_content(urls, config)
            elif site_type == 'documentation':
                content = self._extract_documentation(urls, config)
            elif site_type == 'ecommerce':
                content = self._extract_ecommerce_content(urls, config)
            else:
                content = self.extract_website_content(urls)
                
            all_content.extend(content)
            
        return all_content
    
    def _process_extracted_item(self, item: Dict[str, Any]) -> Optional[ExtractedContent]:
        """Process a single extracted item into ExtractedContent format."""
        try:
            # Extract basic fields
            url = item.get('url', '')
            title = item.get('metadata', {}).get('title', '') or item.get('title', '')
            text = item.get('markdown', '') or item.get('text', '')
            
            # Skip items with insufficient content
            if not text or len(text.strip()) < 100:
                return None
                
            # Calculate word count
            word_count = len(text.split())
            
            # Skip very short content
            if word_count < 50:
                return None
                
            # Extract metadata
            metadata = {
                'title': title,
                'description': item.get('metadata', {}).get('description', ''),
                'author': item.get('metadata', {}).get('author', ''),
                'publishDate': item.get('metadata', {}).get('publishDate', ''),
                'language': item.get('metadata', {}).get('language', 'en'),
                'keywords': item.get('metadata', {}).get('keywords', []),
                'canonicalUrl': item.get('metadata', {}).get('canonicalUrl', url),
                'loadedUrl': item.get('loadedUrl', url),
                'crawlDepth': item.get('depth', 0)
            }
            
            # Determine content type
            content_type = self._determine_content_type(url, title, text, metadata)
            
            return ExtractedContent(
                url=url,
                title=title,
                text=text,
                metadata=metadata,
                extraction_timestamp=datetime.now().isoformat(),
                content_type=content_type,
                word_count=word_count
            )
            
        except Exception as e:
            print(f"Error processing item: {e}")
            return None
    
    def _determine_content_type(self, url: str, title: str, text: str, 
                              metadata: Dict[str, Any]) -> str:
        """Determine the content type based on URL and content analysis."""
        url_lower = url.lower()
        title_lower = title.lower()
        
        # Check for documentation
        if any(keyword in url_lower for keyword in ['docs', 'documentation', 'api', 'guide', 'tutorial']):
            return 'documentation'
            
        # Check for blog/article
        if any(keyword in url_lower for keyword in ['blog', 'article', 'post', 'news']):
            return 'article'
            
        # Check for product pages
        if any(keyword in url_lower for keyword in ['product', 'item', 'shop', 'store']):
            return 'product'
            
        # Check for FAQ/support
        if any(keyword in url_lower for keyword in ['faq', 'help', 'support', 'question']):
            return 'support'
            
        # Default classification
        return 'general'
    
    def _extract_news_content(self, urls: List[str], config: Dict[str, Any]) -> List[ExtractedContent]:
        """Extract content from news websites."""
        # This could use specialized news scrapers
        return self.extract_website_content(urls)
    
    def _extract_documentation(self, urls: List[str], config: Dict[str, Any]) -> List[ExtractedContent]:
        """Extract content from documentation sites."""
        # This could use specialized documentation scrapers
        return self.extract_website_content(urls)
    
    def _extract_ecommerce_content(self, urls: List[str], config: Dict[str, Any]) -> List[ExtractedContent]:
        """Extract content from e-commerce sites."""
        # This could use specialized e-commerce scrapers
        return self.extract_website_content(urls)


class ContentValidator:
    """Validates extracted content for quality and completeness."""
    
    def __init__(self, min_word_count: int = 50, min_title_length: int = 5):
        self.min_word_count = min_word_count
        self.min_title_length = min_title_length
    
    def validate_content(self, content: ExtractedContent) -> bool:
        """Validate a single piece of content."""
        # Check minimum word count
        if content.word_count < self.min_word_count:
            return False
            
        # Check title length
        if len(content.title) < self.min_title_length:
            return False
            
        # Check for valid URL
        if not content.url or not content.url.startswith(('http://', 'https://')):
            return False
            
        # Check for meaningful text content
        if not content.text or len(content.text.strip()) < 100:
            return False
            
        return True
    
    def filter_valid_content(self, content_list: List[ExtractedContent]) -> List[ExtractedContent]:
        """Filter a list of content to only include valid items."""
        return [content for content in content_list if self.validate_content(content)]


class ContentExporter:
    """Exports extracted content to various formats."""
    
    @staticmethod
    def export_to_json(content_list: List[ExtractedContent], 
                      output_path: str) -> None:
        """Export content to JSON format."""
        data = [content.to_dict() for content in content_list]
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            
        print(f"Exported {len(content_list)} items to {output_path}")
    
    @staticmethod
    def export_to_csv(content_list: List[ExtractedContent], 
                     output_path: str) -> None:
        """Export content to CSV format."""
        import csv
        
        fieldnames = ['url', 'title', 'text', 'content_type', 'word_count', 
                     'extraction_timestamp', 'metadata']
        
        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            
            for content in content_list:
                row = content.to_dict()
                row['metadata'] = json.dumps(row['metadata'])
                writer.writerow(row)
                
        print(f"Exported {len(content_list)} items to {output_path}")


def create_sample_extraction_config() -> ExtractionConfig:
    """Create a sample configuration for testing."""
    return ExtractionConfig(
        apify_token="your_apify_token_here",  # Replace with actual token
        max_pages=50,
        max_depth=2,
        include_metadata=True,
        content_types=['article', 'documentation', 'blog']
    )


if __name__ == "__main__":
    # Example usage
    print("Apify Data Extraction Components")
    print("This module provides tools for extracting web content for RAG pipelines.")
    print("Configure with your Apify token and target URLs to begin extraction.")

