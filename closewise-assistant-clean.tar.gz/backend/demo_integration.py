"""
Demonstration of Advanced Apify Integration

This script demonstrates the advanced integration capabilities including
the official Apify-Pinecone integration and workflow orchestration.
"""

import json
from datetime import datetime
from apify_integration import (
    ApifyPineconeIntegration,
    PineconeIntegrationConfig,
    WorkflowOrchestrator,
    create_sample_pinecone_config
)


def demo_pinecone_integration():
    """Demonstrate the Apify-Pinecone integration workflow."""
    print("=== Apify-Pinecone Integration Demo ===")
    print("This demo shows how to use the official integration for RAG pipelines.")
    print()
    
    # Create sample configuration
    config = create_sample_pinecone_config()
    
    print("Configuration Overview:")
    print(f"  Embedding Provider: {config.embedding_provider}")
    print(f"  Embedding Model: {config.embedding_model}")
    print(f"  Chunk Size: {config.chunk_size} characters")
    print(f"  Chunk Overlap: {config.chunk_overlap} characters")
    print(f"  Update Strategy: {config.data_updates_strategy}")
    print(f"  Pinecone Index: {config.pinecone_index_name}")
    print(f"  Namespace: {config.namespace or 'default'}")
    print()
    
    # Sample URLs for extraction
    sample_urls = [
        "https://docs.python.org/3/tutorial/",
        "https://fastapi.tiangolo.com/tutorial/",
        "https://docs.pinecone.io/guides/",
        "https://python.langchain.com/docs/",
        "https://blog.apify.com/category/tutorials/"
    ]
    
    print(f"Target URLs for processing: {len(sample_urls)}")
    for i, url in enumerate(sample_urls, 1):
        print(f"  {i}. {url}")
    print()
    
    # Simulate the integration workflow
    print("Simulated Integration Workflow:")
    print()
    
    print("Step 1: Content Extraction")
    print("  ✓ Initializing Website Content Crawler...")
    print("  ✓ Configuring extraction parameters...")
    print("  ✓ Starting crawl of target URLs...")
    print("  ✓ Extracting and cleaning content...")
    print("  ✓ Saving to Apify dataset...")
    print(f"  → Extracted 127 documents (avg 850 words each)")
    print()
    
    print("Step 2: RAG Processing")
    print("  ✓ Loading content from dataset...")
    print("  ✓ Applying text chunking strategy...")
    print(f"  ✓ Generated 342 chunks (size: {config.chunk_size}, overlap: {config.chunk_overlap})")
    print("  ✓ Generating embeddings with OpenAI...")
    print("  ✓ Processing metadata and enrichment...")
    print()
    
    print("Step 3: Vector Storage")
    print("  ✓ Connecting to Pinecone index...")
    print("  ✓ Performing delta updates...")
    print("  ✓ Storing vectors with metadata...")
    print("  ✓ Updating search index...")
    print(f"  → Stored 342 vectors in '{config.pinecone_index_name}' index")
    print()
    
    # Show sample Actor input configuration
    sample_dataset_id = "dataset_abc123"
    actor_input = config.to_actor_input(sample_dataset_id)
    
    print("Sample Actor Input Configuration:")
    print(json.dumps(actor_input, indent=2))
    print()
    
    # Simulate results
    simulated_results = {
        "success": True,
        "extraction": {
            "success": True,
            "dataset_id": sample_dataset_id,
            "item_count": 127,
            "duration": 180
        },
        "storage": {
            "success": True,
            "processed_chunks": 342,
            "stored_vectors": 342,
            "duration": 95
        },
        "summary": {
            "source_urls": len(sample_urls),
            "extracted_items": 127,
            "processed_chunks": 342,
            "stored_vectors": 342,
            "pipeline_duration": 275
        }
    }
    
    print("Pipeline Results Summary:")
    print(f"  Total Duration: {simulated_results['summary']['pipeline_duration']} seconds")
    print(f"  Documents Extracted: {simulated_results['summary']['extracted_items']}")
    print(f"  Chunks Generated: {simulated_results['summary']['processed_chunks']}")
    print(f"  Vectors Stored: {simulated_results['summary']['stored_vectors']}")
    print(f"  Success Rate: 100%")
    print()


def demo_workflow_orchestration():
    """Demonstrate workflow orchestration capabilities."""
    print("=== Workflow Orchestration Demo ===")
    print("This demo shows advanced workflow management and scheduling.")
    print()
    
    # Sample workflow configurations
    source_configs = [
        {
            "type": "website",
            "name": "Python Documentation",
            "urls": [
                "https://docs.python.org/3/tutorial/",
                "https://docs.python.org/3/library/",
                "https://docs.python.org/3/reference/"
            ],
            "update_frequency": "daily"
        },
        {
            "type": "sitemap",
            "name": "FastAPI Docs",
            "sitemap_url": "https://fastapi.tiangolo.com/sitemap.xml",
            "update_frequency": "weekly"
        },
        {
            "type": "rss",
            "name": "AI News Feed",
            "feed_url": "https://blog.apify.com/feed/",
            "update_frequency": "hourly"
        }
    ]
    
    print(f"Configured Sources: {len(source_configs)}")
    for i, config in enumerate(source_configs, 1):
        print(f"  {i}. {config['name']} ({config['type']}) - {config['update_frequency']}")
    print()
    
    # Create workflow
    print("Creating Scheduled Workflow:")
    workflow_name = "knowledge-base-updates"
    schedule_cron = "0 2 * * *"  # Daily at 2 AM
    
    print(f"  Workflow Name: {workflow_name}")
    print(f"  Schedule: {schedule_cron} (Daily at 2:00 AM)")
    print(f"  Sources: {len(source_configs)} configured")
    print()
    
    # Simulate workflow execution
    print("Simulated Workflow Execution:")
    print()
    
    print("Processing Source 1: Python Documentation")
    print("  ✓ Checking for content updates...")
    print("  ✓ Found 23 new/updated pages")
    print("  ✓ Extracting content...")
    print("  ✓ Processing through RAG pipeline...")
    print("  ✓ Storing 67 new vectors")
    print()
    
    print("Processing Source 2: FastAPI Docs")
    print("  ✓ Parsing sitemap...")
    print("  ✓ Found 8 new/updated pages")
    print("  ✓ Extracting content...")
    print("  ✓ Processing through RAG pipeline...")
    print("  ✓ Storing 24 new vectors")
    print()
    
    print("Processing Source 3: AI News Feed")
    print("  ✓ Parsing RSS feed...")
    print("  ✓ Found 5 new articles")
    print("  ✓ Extracting content...")
    print("  ✓ Processing through RAG pipeline...")
    print("  ✓ Storing 15 new vectors")
    print()
    
    # Simulate results
    workflow_results = {
        "success": True,
        "workflow_name": workflow_name,
        "sources_processed": 3,
        "successful_sources": 3,
        "total_items_processed": 36,
        "new_vectors_stored": 106,
        "execution_time": 420,
        "timestamp": datetime.now().isoformat()
    }
    
    print("Workflow Execution Summary:")
    print(f"  Execution Time: {workflow_results['execution_time']} seconds")
    print(f"  Sources Processed: {workflow_results['sources_processed']}")
    print(f"  Success Rate: {workflow_results['successful_sources']}/{workflow_results['sources_processed']} (100%)")
    print(f"  Items Processed: {workflow_results['total_items_processed']}")
    print(f"  New Vectors: {workflow_results['new_vectors_stored']}")
    print()


def show_real_implementation_guide():
    """Show how to implement the integration with real API tokens."""
    print("=== Real Implementation Guide ===")
    print()
    
    implementation_steps = """
To implement the Apify-Pinecone integration with real API tokens:

1. Get Required API Keys:
   - Apify Token: https://console.apify.com/account/integrations
   - Pinecone API Key: https://app.pinecone.io/
   - OpenAI API Key: https://platform.openai.com/api-keys

2. Create Pinecone Index:
   - Dimension: 3072 (for text-embedding-3-large)
   - Metric: cosine
   - Cloud: AWS/GCP (your preference)

3. Configure Integration:
   ```python
   config = PineconeIntegrationConfig(
       apify_token="apify_api_...",
       pinecone_api_key="pc-...",
       pinecone_index_name="your-index-name",
       embedding_provider="OpenAI",
       embedding_api_key="sk-...",
       embedding_model="text-embedding-3-large",
       chunk_size=1000,
       chunk_overlap=200,
       namespace="documents"
   )
   ```

4. Run Integration:
   ```python
   integration = ApifyPineconeIntegration(config)
   
   urls = ["https://your-target-site.com"]
   result = integration.run_extraction_and_storage_pipeline(urls)
   
   if result["success"]:
       print(f"Stored {result['summary']['stored_vectors']} vectors")
   ```

5. Set Up Monitoring:
   - Monitor Apify Actor runs
   - Track Pinecone usage and costs
   - Set up alerts for failures
   - Review content quality regularly

6. Optimize Performance:
   - Adjust chunk sizes based on content type
   - Use delta updates for efficiency
   - Implement content deduplication
   - Monitor embedding costs

Cost Estimates (monthly):
- Apify: $50-200 (depending on crawl volume)
- OpenAI Embeddings: $10-100 (depending on content volume)
- Pinecone: $70+ (depending on vector count and queries)
"""
    
    print(implementation_steps)


def show_integration_benefits():
    """Show the benefits of using the official integration."""
    print("=== Integration Benefits ===")
    print()
    
    benefits = [
        "✓ Official Support: Maintained by Apify with regular updates",
        "✓ Proven Reliability: Used by enterprise customers in production",
        "✓ Built-in Optimization: Automatic batching, retry logic, error handling",
        "✓ Delta Updates: Efficient incremental processing",
        "✓ Multiple Providers: Support for OpenAI, Cohere, HuggingFace",
        "✓ Flexible Chunking: Configurable text splitting strategies",
        "✓ Metadata Preservation: Rich metadata mapping and filtering",
        "✓ Cost Optimization: Deduplication and efficient API usage",
        "✓ Monitoring: Built-in logging and progress tracking",
        "✓ Scalability: Automatic scaling with Apify infrastructure"
    ]
    
    for benefit in benefits:
        print(f"  {benefit}")
    print()
    
    print("Comparison with Custom Implementation:")
    print()
    
    comparison = [
        ("Development Time", "Days", "Weeks/Months"),
        ("Maintenance Effort", "Minimal", "Significant"),
        ("Error Handling", "Built-in", "Custom Required"),
        ("Optimization", "Automatic", "Manual Tuning"),
        ("Updates", "Automatic", "Manual Updates"),
        ("Support", "Official", "Self-Support"),
        ("Testing", "Pre-tested", "Extensive Testing Required"),
        ("Documentation", "Complete", "Self-Documented")
    ]
    
    print(f"{'Aspect':<20} {'Integration':<15} {'Custom Build':<20}")
    print("-" * 55)
    for aspect, integration, custom in comparison:
        print(f"{aspect:<20} {integration:<15} {custom:<20}")
    print()


if __name__ == "__main__":
    # Run all demonstrations
    demo_pinecone_integration()
    print("\n" + "="*60 + "\n")
    
    demo_workflow_orchestration()
    print("\n" + "="*60 + "\n")
    
    show_integration_benefits()
    print("\n" + "="*60 + "\n")
    
    show_real_implementation_guide()

