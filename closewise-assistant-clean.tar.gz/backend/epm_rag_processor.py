"""
Oracle EPM Cloud RAG Processing Pipeline

This module provides specialized RAG processing components for Oracle EPM Cloud content,
designed for the Wiseclose Oracle EPM Cloud Assistant.
"""

import os
import json
import re
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain.schema import Document
import tiktoken


class EPMModule(Enum):
    """Oracle EPM Cloud modules."""
    PLANNING = "planning"
    FCCS = "fccs"  # Financial Consolidation and Close
    ARCS = "arcs"  # Account Reconciliation
    PCMCS = "pcmcs"  # Profitability and Cost Management
    TRCS = "trcs"  # Tax Reporting
    NARRATIVE = "narrative"  # Narrative Reporting
    GENERAL = "general"


@dataclass
class EPMContent:
    """Represents Oracle EPM Cloud content with specialized metadata."""
    text: str
    title: str
    url: str
    module: EPMModule
    content_type: str  # procedure, configuration, troubleshooting, concept
    language: str = "pt"  # Portuguese primary, English secondary
    difficulty_level: str = "intermediate"  # beginner, intermediate, advanced
    version: str = ""
    last_updated: str = ""
    tags: List[str] = field(default_factory=list)
    related_modules: List[EPMModule] = field(default_factory=list)
    
    def to_document(self) -> Document:
        """Convert to LangChain Document format."""
        metadata = {
            "title": self.title,
            "url": self.url,
            "module": self.module.value,
            "content_type": self.content_type,
            "language": self.language,
            "difficulty_level": self.difficulty_level,
            "version": self.version,
            "last_updated": self.last_updated,
            "tags": self.tags,
            "related_modules": [m.value for m in self.related_modules]
        }
        return Document(page_content=self.text, metadata=metadata)


@dataclass
class EPMChunk:
    """Represents a processed chunk of EPM content."""
    text: str
    metadata: Dict[str, Any]
    embedding: Optional[List[float]] = None
    chunk_id: str = ""
    parent_document_id: str = ""
    chunk_index: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage."""
        return {
            "text": self.text,
            "metadata": self.metadata,
            "embedding": self.embedding,
            "chunk_id": self.chunk_id,
            "parent_document_id": self.parent_document_id,
            "chunk_index": self.chunk_index
        }


class EPMContentClassifier:
    """Classifies Oracle EPM content by module and type."""
    
    def __init__(self):
        """Initialize the classifier with EPM-specific patterns."""
        self.module_patterns = {
            EPMModule.PLANNING: [
                "planning", "budget", "forecast", "plan", "dimensão", "dimension",
                "smart view", "smartview", "forms", "formulários", "rules", "regras",
                "calc script", "calculation", "cálculo", "business rules"
            ],
            EPMModule.FCCS: [
                "consolidation", "consolidação", "close", "fechamento", "fccs",
                "elimination", "eliminação", "currency", "moeda", "translation",
                "tradução", "intercompany", "intercompanhia"
            ],
            EPMModule.ARCS: [
                "reconciliation", "reconciliação", "arcs", "account", "conta",
                "balance", "saldo", "variance", "variação", "certification",
                "certificação", "workflow", "fluxo"
            ],
            EPMModule.PCMCS: [
                "profitability", "rentabilidade", "cost", "custo", "pcmcs",
                "allocation", "alocação", "driver", "direcionador", "model",
                "modelo", "stage", "estágio"
            ],
            EPMModule.TRCS: [
                "tax", "imposto", "trcs", "reporting", "relatório", "compliance",
                "conformidade", "jurisdiction", "jurisdição", "provision",
                "provisão"
            ],
            EPMModule.NARRATIVE: [
                "narrative", "narrativa", "report", "relatório", "document",
                "documento", "template", "modelo", "package", "pacote"
            ]
        }
        
        self.content_type_patterns = {
            "procedure": [
                "how to", "como", "step", "passo", "procedure", "procedimento",
                "process", "processo", "guide", "guia", "tutorial"
            ],
            "configuration": [
                "configure", "configurar", "setup", "configuração", "setting",
                "definição", "parameter", "parâmetro", "property", "propriedade"
            ],
            "troubleshooting": [
                "error", "erro", "issue", "problema", "troubleshoot", "solução",
                "fix", "corrigir", "resolve", "resolver", "debug"
            ],
            "concept": [
                "overview", "visão geral", "concept", "conceito", "introduction",
                "introdução", "about", "sobre", "what is", "o que é"
            ]
        }
    
    def classify_module(self, content: str, title: str = "") -> EPMModule:
        """Classify content by EPM module."""
        text = (content + " " + title).lower()
        
        module_scores = {}
        for module, patterns in self.module_patterns.items():
            score = sum(1 for pattern in patterns if pattern in text)
            if score > 0:
                module_scores[module] = score
        
        if module_scores:
            return max(module_scores.items(), key=lambda x: x[1])[0]
        
        return EPMModule.GENERAL
    
    def classify_content_type(self, content: str, title: str = "") -> str:
        """Classify content type."""
        text = (content + " " + title).lower()
        
        type_scores = {}
        for content_type, patterns in self.content_type_patterns.items():
            score = sum(1 for pattern in patterns if pattern in text)
            if score > 0:
                type_scores[content_type] = score
        
        if type_scores:
            return max(type_scores.items(), key=lambda x: x[1])[0]
        
        return "general"
    
    def detect_language(self, content: str) -> str:
        """Detect content language (Portuguese or English)."""
        portuguese_indicators = [
            "configuração", "procedimento", "relatório", "dimensão", "cálculo",
            "consolidação", "reconciliação", "rentabilidade", "imposto",
            "como", "para", "com", "uma", "dos", "das", "que", "não"
        ]
        
        english_indicators = [
            "configuration", "procedure", "report", "dimension", "calculation",
            "consolidation", "reconciliation", "profitability", "tax",
            "how", "for", "with", "the", "and", "that", "not"
        ]
        
        content_lower = content.lower()
        pt_score = sum(1 for indicator in portuguese_indicators if indicator in content_lower)
        en_score = sum(1 for indicator in english_indicators if indicator in content_lower)
        
        return "pt" if pt_score > en_score else "en"


class EPMTextSplitter:
    """Specialized text splitter for Oracle EPM content."""
    
    def __init__(self, 
                 chunk_size: int = 1000,
                 chunk_overlap: int = 200,
                 preserve_epm_structure: bool = True):
        """Initialize the EPM text splitter."""
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.preserve_epm_structure = preserve_epm_structure
        
        # EPM-specific separators
        self.epm_separators = [
            "\n## ",  # Section headers
            "\n### ",  # Subsection headers
            "\n#### ",  # Sub-subsection headers
            "\nStep ",  # Procedure steps
            "\nPasso ",  # Portuguese procedure steps
            "\n\n",  # Paragraph breaks
            "\n",  # Line breaks
            ". ",  # Sentence breaks
            " ",  # Word breaks
            ""
        ]
        
        self.base_splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            separators=self.epm_separators,
            keep_separator=True
        )
    
    def split_epm_content(self, epm_content: EPMContent) -> List[EPMChunk]:
        """Split EPM content into optimized chunks."""
        document = epm_content.to_document()
        
        # Use base splitter for initial chunking
        chunks = self.base_splitter.split_documents([document])
        
        epm_chunks = []
        for i, chunk in enumerate(chunks):
            # Enhance metadata with EPM-specific information
            enhanced_metadata = chunk.metadata.copy()
            enhanced_metadata.update({
                "chunk_index": i,
                "total_chunks": len(chunks),
                "chunk_size": len(chunk.page_content),
                "word_count": len(chunk.page_content.split())
            })
            
            # Generate unique chunk ID
            chunk_id = f"{epm_content.module.value}_{hash(epm_content.url)}_{i}"
            
            epm_chunk = EPMChunk(
                text=chunk.page_content,
                metadata=enhanced_metadata,
                chunk_id=chunk_id,
                parent_document_id=epm_content.url,
                chunk_index=i
            )
            
            epm_chunks.append(epm_chunk)
        
        return epm_chunks
    
    def optimize_chunk_boundaries(self, chunks: List[EPMChunk]) -> List[EPMChunk]:
        """Optimize chunk boundaries for EPM content."""
        optimized_chunks = []
        
        for chunk in chunks:
            text = chunk.text
            
            # Ensure procedures don't split mid-step
            if "Step " in text or "Passo " in text:
                text = self._preserve_procedure_steps(text)
            
            # Ensure code blocks stay together
            if "```" in text or "<code>" in text:
                text = self._preserve_code_blocks(text)
            
            # Update chunk with optimized text
            chunk.text = text
            optimized_chunks.append(chunk)
        
        return optimized_chunks
    
    def _preserve_procedure_steps(self, text: str) -> str:
        """Ensure procedure steps are not split."""
        # This would implement logic to keep procedure steps together
        return text
    
    def _preserve_code_blocks(self, text: str) -> str:
        """Ensure code blocks are not split."""
        # This would implement logic to keep code blocks together
        return text


class EPMEmbeddingGenerator:
    """Generates embeddings optimized for Oracle EPM content."""
    
    def __init__(self, 
                 openai_api_key: str,
                 model: str = "text-embedding-3-large",
                 batch_size: int = 100):
        """Initialize the embedding generator."""
        self.embeddings = OpenAIEmbeddings(
            openai_api_key=openai_api_key,
            model=model
        )
        self.batch_size = batch_size
        self.model = model
        
        # Initialize tokenizer for token counting
        self.tokenizer = tiktoken.encoding_for_model("gpt-3.5-turbo")
    
    def generate_embeddings(self, chunks: List[EPMChunk]) -> List[EPMChunk]:
        """Generate embeddings for EPM chunks."""
        print(f"Generating embeddings for {len(chunks)} chunks...")
        
        # Process in batches
        for i in range(0, len(chunks), self.batch_size):
            batch = chunks[i:i + self.batch_size]
            batch_texts = [chunk.text for chunk in batch]
            
            try:
                # Generate embeddings for batch
                batch_embeddings = self.embeddings.embed_documents(batch_texts)
                
                # Assign embeddings to chunks
                for chunk, embedding in zip(batch, batch_embeddings):
                    chunk.embedding = embedding
                    
                print(f"Processed batch {i//self.batch_size + 1}/{(len(chunks)-1)//self.batch_size + 1}")
                
            except Exception as e:
                print(f"Error generating embeddings for batch {i//self.batch_size + 1}: {e}")
                # Continue with next batch
                continue
        
        # Filter out chunks without embeddings
        successful_chunks = [chunk for chunk in chunks if chunk.embedding is not None]
        print(f"Successfully generated embeddings for {len(successful_chunks)}/{len(chunks)} chunks")
        
        return successful_chunks
    
    def estimate_cost(self, chunks: List[EPMChunk]) -> Dict[str, float]:
        """Estimate embedding generation cost."""
        total_tokens = 0
        for chunk in chunks:
            tokens = len(self.tokenizer.encode(chunk.text))
            total_tokens += tokens
        
        # OpenAI pricing for text-embedding-3-large: $0.13 per 1M tokens
        cost_per_million = 0.13
        estimated_cost = (total_tokens / 1_000_000) * cost_per_million
        
        return {
            "total_tokens": total_tokens,
            "estimated_cost_usd": estimated_cost,
            "cost_per_chunk": estimated_cost / len(chunks) if chunks else 0
        }


class EPMContentProcessor:
    """Main processor for Oracle EPM content."""
    
    def __init__(self, 
                 openai_api_key: str,
                 chunk_size: int = 1000,
                 chunk_overlap: int = 200):
        """Initialize the EPM content processor."""
        self.classifier = EPMContentClassifier()
        self.text_splitter = EPMTextSplitter(chunk_size, chunk_overlap)
        self.embedding_generator = EPMEmbeddingGenerator(openai_api_key)
        
    def process_extracted_content(self, extracted_items: List[Dict[str, Any]]) -> List[EPMChunk]:
        """Process extracted content into EPM chunks with embeddings."""
        print(f"Processing {len(extracted_items)} extracted items...")
        
        # Convert to EPM content objects
        epm_contents = []
        for item in extracted_items:
            epm_content = self._convert_to_epm_content(item)
            if epm_content:
                epm_contents.append(epm_content)
        
        print(f"Converted {len(epm_contents)} items to EPM content")
        
        # Split into chunks
        all_chunks = []
        for epm_content in epm_contents:
            chunks = self.text_splitter.split_epm_content(epm_content)
            all_chunks.extend(chunks)
        
        print(f"Generated {len(all_chunks)} chunks")
        
        # Optimize chunk boundaries
        optimized_chunks = self.text_splitter.optimize_chunk_boundaries(all_chunks)
        
        # Generate embeddings
        chunks_with_embeddings = self.embedding_generator.generate_embeddings(optimized_chunks)
        
        return chunks_with_embeddings
    
    def _convert_to_epm_content(self, item: Dict[str, Any]) -> Optional[EPMContent]:
        """Convert extracted item to EPM content."""
        try:
            text = item.get("text", "")
            title = item.get("title", "")
            url = item.get("url", "")
            
            if not text or len(text.strip()) < 100:
                return None
            
            # Classify content
            module = self.classifier.classify_module(text, title)
            content_type = self.classifier.classify_content_type(text, title)
            language = self.classifier.detect_language(text)
            
            # Extract additional metadata
            tags = self._extract_tags(text, title)
            related_modules = self._find_related_modules(text, module)
            
            return EPMContent(
                text=text,
                title=title,
                url=url,
                module=module,
                content_type=content_type,
                language=language,
                tags=tags,
                related_modules=related_modules,
                last_updated=item.get("extraction_timestamp", "")
            )
            
        except Exception as e:
            print(f"Error converting item to EPM content: {e}")
            return None
    
    def _extract_tags(self, text: str, title: str) -> List[str]:
        """Extract relevant tags from content."""
        content = (text + " " + title).lower()
        
        epm_tags = {
            "smartview", "smart view", "forms", "formulários", "rules", "regras",
            "calculation", "cálculo", "dimension", "dimensão", "hierarchy", "hierarquia",
            "workflow", "fluxo", "approval", "aprovação", "security", "segurança",
            "integration", "integração", "data load", "carga", "export", "exportar",
            "import", "importar", "backup", "restore", "migration", "migração"
        }
        
        found_tags = [tag for tag in epm_tags if tag in content]
        return found_tags[:10]  # Limit to 10 tags
    
    def _find_related_modules(self, text: str, primary_module: EPMModule) -> List[EPMModule]:
        """Find related EPM modules mentioned in content."""
        related = []
        content = text.lower()
        
        for module, patterns in self.classifier.module_patterns.items():
            if module != primary_module:
                if any(pattern in content for pattern in patterns):
                    related.append(module)
        
        return related[:3]  # Limit to 3 related modules
    
    def get_processing_stats(self, chunks: List[EPMChunk]) -> Dict[str, Any]:
        """Get processing statistics."""
        if not chunks:
            return {"error": "No chunks to analyze"}
        
        # Module distribution
        module_counts = {}
        for chunk in chunks:
            module = chunk.metadata.get("module", "unknown")
            module_counts[module] = module_counts.get(module, 0) + 1
        
        # Content type distribution
        type_counts = {}
        for chunk in chunks:
            content_type = chunk.metadata.get("content_type", "unknown")
            type_counts[content_type] = type_counts.get(content_type, 0) + 1
        
        # Language distribution
        lang_counts = {}
        for chunk in chunks:
            language = chunk.metadata.get("language", "unknown")
            lang_counts[language] = lang_counts.get(language, 0) + 1
        
        # Size statistics
        chunk_sizes = [len(chunk.text) for chunk in chunks]
        word_counts = [chunk.metadata.get("word_count", 0) for chunk in chunks]
        
        return {
            "total_chunks": len(chunks),
            "module_distribution": module_counts,
            "content_type_distribution": type_counts,
            "language_distribution": lang_counts,
            "size_stats": {
                "avg_chunk_size": sum(chunk_sizes) / len(chunk_sizes),
                "min_chunk_size": min(chunk_sizes),
                "max_chunk_size": max(chunk_sizes),
                "avg_word_count": sum(word_counts) / len(word_counts)
            },
            "embedding_stats": {
                "chunks_with_embeddings": sum(1 for chunk in chunks if chunk.embedding),
                "embedding_dimensions": len(chunks[0].embedding) if chunks and chunks[0].embedding else 0
            }
        }


def create_sample_epm_content() -> List[Dict[str, Any]]:
    """Create sample Oracle EPM content for testing."""
    return [
        {
            "url": "https://docs.oracle.com/en/cloud/saas/planning-budgeting-cloud/pfusu/",
            "title": "Oracle Planning and Budgeting Cloud - User Guide",
            "text": """Oracle Planning and Budgeting Cloud (PBCS) é uma solução completa de planejamento empresarial que permite às organizações criar orçamentos, previsões e planos estratégicos. 

Como configurar dimensões no Planning:
1. Acesse a aplicação Planning
2. Navegue até Application > Overview > Dimensions
3. Clique em Actions > Edit para modificar uma dimensão existente
4. Configure as propriedades da dimensão conforme necessário
5. Salve as alterações

As dimensões são elementos fundamentais que definem a estrutura dos dados no Planning. Cada dimensão representa uma perspectiva diferente dos dados, como Entidade, Conta, Período, Cenário, etc.""",
            "content_type": "procedure",
            "extraction_timestamp": "2025-06-14T12:00:00Z"
        },
        {
            "url": "https://docs.oracle.com/en/cloud/saas/financial-consolidation-cloud/",
            "title": "FCCS - Financial Consolidation and Close Cloud Service",
            "text": """Financial Consolidation and Close Cloud Service (FCCS) provides a complete solution for financial consolidation and close processes.

Troubleshooting Common FCCS Issues:

Error: "Consolidation failed with currency translation error"
Solution: 
1. Verify that all required exchange rates are loaded
2. Check the currency translation rules in the application
3. Ensure that the base currency is properly configured
4. Review the consolidation log for specific error details

The consolidation process in FCCS involves multiple steps including data collection, currency translation, elimination entries, and final consolidation calculations.""",
            "content_type": "troubleshooting",
            "extraction_timestamp": "2025-06-14T12:00:00Z"
        },
        {
            "url": "https://docs.oracle.com/en/cloud/saas/account-reconciliation-cloud/",
            "title": "ARCS - Account Reconciliation Overview",
            "text": """Account Reconciliation Cloud Service (ARCS) automatiza e simplifica o processo de reconciliação de contas, fornecendo controles internos robustos e conformidade regulatória.

Conceitos principais do ARCS:
- Reconciliações: Processo de comparação e validação de saldos contábeis
- Certificação: Aprovação formal das reconciliações pelos responsáveis
- Workflow: Fluxo automatizado de aprovações e revisões
- Variações: Diferenças identificadas durante o processo de reconciliação

O ARCS integra-se com outros módulos EPM como FCCS para fornecer uma visão completa do processo de fechamento financeiro.""",
            "content_type": "concept",
            "extraction_timestamp": "2025-06-14T12:00:00Z"
        }
    ]


if __name__ == "__main__":
    print("Oracle EPM Cloud RAG Processing Pipeline")
    print("Specialized components for Wiseclose Oracle EPM Cloud Assistant")
    print("Supports Portuguese and English content processing")

