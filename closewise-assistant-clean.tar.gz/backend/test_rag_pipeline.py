"""
Full RAG Pipeline Test for CloseWise Assistant

This script tests the complete Apify-RAG-Pinecone pipeline with real queries.
"""

import os
import json
from typing import List, Dict, Any
from pinecone import Pinecone
import openai
from api_config import config


class CloseWiseRAGTester:
    """Tests the complete RAG pipeline."""
    
    def __init__(self):
        """Initialize the RAG tester."""
        # Initialize clients
        self.pinecone = Pinecone(api_key=config.pinecone_api_key)
        self.openai_client = openai.OpenAI(api_key=config.openai_api_key)
        
        # Get Pinecone index
        self.index = self.pinecone.Index(config.pinecone_index_name)
        
        print("✅ CloseWise RAG Tester initialized")
    
    def test_vector_search(self, query: str, top_k: int = 3) -> List[Dict[str, Any]]:
        """Test vector similarity search."""
        print(f"🔍 Testing vector search for: '{query}'")
        
        try:
            # Generate query embedding
            response = self.openai_client.embeddings.create(
                model=config.embedding_model,
                input=query
            )
            
            query_embedding = response.data[0].embedding
            
            # Search in Pinecone
            search_response = self.index.query(
                vector=query_embedding,
                top_k=top_k,
                include_metadata=True
            )
            
            results = []
            for match in search_response['matches']:
                results.append({
                    "id": match['id'],
                    "score": match['score'],
                    "text": match['metadata'].get('text', ''),
                    "title": match['metadata'].get('title', ''),
                    "module": match['metadata'].get('module', ''),
                    "url": match['metadata'].get('url', '')
                })
            
            print(f"✅ Found {len(results)} relevant results")
            return results
            
        except Exception as e:
            print(f"❌ Vector search failed: {e}")
            return []
    
    def generate_rag_response(self, query: str, context_results: List[Dict[str, Any]], language: str = "pt") -> str:
        """Generate RAG response using retrieved context."""
        print(f"🤖 Generating RAG response in {language}")
        
        try:
            # Build context from search results
            context = "\n\n".join([
                f"Fonte: {result['title']} ({result['module'].upper()})\n{result['text']}"
                for result in context_results
            ])
            
            # Create system prompt based on language
            if language == "pt":
                system_prompt = """Você é o CloseWise Assistant, um especialista em Oracle EPM Cloud.
                
Responda às perguntas sobre Oracle EPM usando o contexto fornecido. Seja preciso, útil e profissional.
Sempre cite as fontes quando relevante. Se não souber algo, seja honesto sobre isso.

Foque nos módulos: FCCS, EPBCS, Essbase, ARCS, Workforce Planning."""
                
                user_prompt = f"""Contexto relevante:
{context}

Pergunta do usuário: {query}

Forneça uma resposta detalhada e útil em português, citando as fontes quando apropriado."""
            
            else:
                system_prompt = """You are CloseWise Assistant, an Oracle EPM Cloud specialist.
                
Answer questions about Oracle EPM using the provided context. Be precise, helpful, and professional.
Always cite sources when relevant. If you don't know something, be honest about it.

Focus on modules: FCCS, EPBCS, Essbase, ARCS, Workforce Planning."""
                
                user_prompt = f"""Relevant context:
{context}

User question: {query}

Provide a detailed and helpful response in English, citing sources when appropriate."""
            
            # Generate response
            response = self.openai_client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.7,
                max_tokens=1000
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            print(f"❌ RAG response generation failed: {e}")
            return "Desculpe, ocorreu um erro ao gerar a resposta." if language == "pt" else "Sorry, an error occurred while generating the response."
    
    def test_complete_rag_pipeline(self, test_queries: List[Dict[str, str]]):
        """Test the complete RAG pipeline with multiple queries."""
        print("🧪 Testing complete RAG pipeline...")
        
        results = []
        
        for i, test_case in enumerate(test_queries, 1):
            query = test_case["query"]
            language = test_case.get("language", "pt")
            expected_module = test_case.get("expected_module", "")
            
            print(f"\n--- Test Case {i}: {query} ---")
            
            # Step 1: Vector search
            search_results = self.test_vector_search(query)
            
            if not search_results:
                print("❌ No search results found")
                continue
            
            # Step 2: Generate RAG response
            rag_response = self.generate_rag_response(query, search_results, language)
            
            # Step 3: Analyze results
            found_modules = set(result['module'] for result in search_results)
            best_score = max(result['score'] for result in search_results) if search_results else 0
            
            test_result = {
                "query": query,
                "language": language,
                "expected_module": expected_module,
                "found_modules": list(found_modules),
                "best_score": best_score,
                "num_results": len(search_results),
                "response": rag_response,
                "success": best_score > 0.7  # Threshold for relevance
            }
            
            results.append(test_result)
            
            # Display results
            print(f"📊 Results:")
            print(f"   Found modules: {found_modules}")
            print(f"   Best score: {best_score:.3f}")
            print(f"   Response preview: {rag_response[:200]}...")
            
            if expected_module and expected_module in found_modules:
                print("✅ Expected module found!")
            elif expected_module:
                print(f"⚠️ Expected module '{expected_module}' not found")
        
        return results
    
    def run_comprehensive_test(self):
        """Run comprehensive RAG pipeline tests."""
        print("CloseWise Assistant - Complete RAG Pipeline Test")
        print("=" * 55)
        
        # Test queries covering different EPM modules
        test_queries = [
            {
                "query": "Como resolver erros de tradução de moeda no FCCS?",
                "language": "pt",
                "expected_module": "fccs"
            },
            {
                "query": "Como configurar dimensões no Planning?",
                "language": "pt", 
                "expected_module": "epbcs"
            },
            {
                "query": "How to optimize Essbase calculation performance?",
                "language": "en",
                "expected_module": "essbase"
            },
            {
                "query": "Quais são os passos para consolidação financeira?",
                "language": "pt",
                "expected_module": "fccs"
            },
            {
                "query": "EPBCS form configuration best practices",
                "language": "en",
                "expected_module": "epbcs"
            }
        ]
        
        # Run tests
        results = self.test_complete_rag_pipeline(test_queries)
        
        # Summary
        print(f"\n📈 Test Summary:")
        print(f"   Total tests: {len(results)}")
        successful_tests = [r for r in results if r['success']]
        print(f"   Successful: {len(successful_tests)}")
        print(f"   Success rate: {len(successful_tests)/len(results)*100:.1f}%")
        
        avg_score = sum(r['best_score'] for r in results) / len(results) if results else 0
        print(f"   Average relevance score: {avg_score:.3f}")
        
        # Module coverage
        all_modules = set()
        for r in results:
            all_modules.update(r['found_modules'])
        print(f"   Modules covered: {sorted(all_modules)}")
        
        if len(successful_tests) >= len(results) * 0.8:  # 80% success rate
            print("\n🎉 RAG Pipeline Test: PASSED!")
            print("The CloseWise Assistant is ready for production!")
        else:
            print("\n⚠️ RAG Pipeline Test: NEEDS IMPROVEMENT")
            print("Consider adding more content or tuning parameters.")
        
        return results


def main():
    """Main test function."""
    try:
        # Initialize tester
        tester = CloseWiseRAGTester()
        
        # Run comprehensive test
        results = tester.run_comprehensive_test()
        
        # Save results
        with open('/home/ubuntu/rag_test_results.json', 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        
        print(f"\n📄 Test results saved to: /home/ubuntu/rag_test_results.json")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")


if __name__ == "__main__":
    main()

