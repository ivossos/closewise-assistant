"""
CloseWise Assistant Frontend Integration

This module creates the React frontend that integrates with the Apify-RAG-Pinecone pipeline
for the CloseWise Oracle EPM support assistant.
"""

import os
import json
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime

from epm_rag_processor import EPMContentProcessor, EPMChunk


@dataclass
class ChatMessage:
    """Represents a chat message in the CloseWise interface."""
    id: str
    content: str
    role: str  # 'user' or 'assistant'
    timestamp: str
    module: Optional[str] = None
    confidence: Optional[float] = None
    sources: List[Dict[str, str]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "content": self.content,
            "role": self.role,
            "timestamp": self.timestamp,
            "module": self.module,
            "confidence": self.confidence,
            "sources": self.sources or []
        }


class CloseWiseBackend:
    """Backend service for the CloseWise Assistant."""
    
    def __init__(self, 
                 openai_api_key: str,
                 pinecone_api_key: str = None,
                 pinecone_index_name: str = "closewise-epm"):
        """Initialize the CloseWise backend."""
        self.openai_api_key = openai_api_key
        self.pinecone_api_key = pinecone_api_key
        self.pinecone_index_name = pinecone_index_name
        
        # Initialize EPM processor
        self.epm_processor = EPMContentProcessor(openai_api_key)
        
        # Initialize chat history
        self.chat_sessions = {}
        
        # EPM module mappings
        self.epm_modules = {
            "fccs": "Financial Consolidation and Close",
            "epbcs": "Enterprise Planning and Budgeting",
            "pbcs": "Planning and Budgeting Cloud Service",
            "essbase": "Essbase Analytics",
            "arcs": "Account Reconciliation",
            "pcmcs": "Profitability and Cost Management",
            "workforce": "Workforce Planning",
            "narrative": "Narrative Reporting",
            "trcs": "Tax Reporting"
        }
    
    def process_chat_message(self, 
                           session_id: str,
                           user_message: str,
                           language: str = "pt") -> ChatMessage:
        """Process a user chat message and generate assistant response."""
        
        # Initialize session if needed
        if session_id not in self.chat_sessions:
            self.chat_sessions[session_id] = []
        
        # Add user message to session
        user_msg = ChatMessage(
            id=f"user_{len(self.chat_sessions[session_id])}",
            content=user_message,
            role="user",
            timestamp=datetime.now().isoformat()
        )
        self.chat_sessions[session_id].append(user_msg)
        
        # Detect EPM module from message
        detected_module = self._detect_epm_module(user_message)
        
        # Search relevant content (simulated for now)
        relevant_chunks = self._search_relevant_content(user_message, detected_module)
        
        # Generate response
        assistant_response = self._generate_assistant_response(
            user_message, relevant_chunks, language, detected_module
        )
        
        # Create assistant message
        assistant_msg = ChatMessage(
            id=f"assistant_{len(self.chat_sessions[session_id])}",
            content=assistant_response["content"],
            role="assistant",
            timestamp=datetime.now().isoformat(),
            module=detected_module,
            confidence=assistant_response.get("confidence", 0.8),
            sources=assistant_response.get("sources", [])
        )
        
        self.chat_sessions[session_id].append(assistant_msg)
        
        return assistant_msg
    
    def _detect_epm_module(self, message: str) -> Optional[str]:
        """Detect which EPM module the message is about."""
        message_lower = message.lower()
        
        # Module detection patterns
        module_patterns = {
            "fccs": ["fccs", "consolidation", "consolidação", "elimination", "eliminação", "close", "fechamento"],
            "epbcs": ["epbcs", "pbcs", "planning", "planejamento", "budget", "orçamento", "forecast", "previsão"],
            "essbase": ["essbase", "calculation", "cálculo", "script", "cube", "cubo", "outline"],
            "arcs": ["arcs", "reconciliation", "reconciliação", "certification", "certificação"],
            "workforce": ["workforce", "força de trabalho", "salary", "salário", "headcount", "funcionários"],
            "pcmcs": ["pcmcs", "profitability", "rentabilidade", "cost", "custo", "allocation", "alocação"],
            "narrative": ["narrative", "narrativa", "report", "relatório", "document", "documento"],
            "trcs": ["trcs", "tax", "imposto", "compliance", "conformidade"]
        }
        
        for module, patterns in module_patterns.items():
            if any(pattern in message_lower for pattern in patterns):
                return module
        
        return None
    
    def _search_relevant_content(self, query: str, module: Optional[str] = None) -> List[Dict[str, Any]]:
        """Search for relevant content in the knowledge base."""
        # This would integrate with Pinecone for actual vector search
        # For now, return simulated relevant content
        
        sample_sources = [
            {
                "title": "FCCS Consolidation Process Guide",
                "url": "https://docs.oracle.com/en/cloud/saas/financial-consolidation-cloud/",
                "content": "Processo de consolidação no FCCS envolve coleta de dados, tradução de moeda, eliminações e cálculos finais...",
                "module": "fccs",
                "confidence": 0.92
            },
            {
                "title": "Planning Dimension Configuration",
                "url": "https://docs.oracle.com/en/cloud/saas/planning-budgeting-cloud/",
                "content": "Configuração de dimensões no Planning requer definição de hierarquias, propriedades e relacionamentos...",
                "module": "epbcs",
                "confidence": 0.87
            }
        ]
        
        # Filter by module if specified
        if module:
            sample_sources = [s for s in sample_sources if s["module"] == module]
        
        return sample_sources[:3]  # Return top 3 results
    
    def _generate_assistant_response(self, 
                                   user_message: str,
                                   relevant_chunks: List[Dict[str, Any]],
                                   language: str,
                                   module: Optional[str]) -> Dict[str, Any]:
        """Generate assistant response using RAG."""
        
        # Build context from relevant chunks
        context = "\n\n".join([chunk["content"] for chunk in relevant_chunks])
        
        # Generate response based on language preference
        if language == "pt":
            response_content = self._generate_portuguese_response(user_message, context, module)
        else:
            response_content = self._generate_english_response(user_message, context, module)
        
        # Extract sources
        sources = [
            {
                "title": chunk["title"],
                "url": chunk["url"],
                "confidence": chunk["confidence"]
            }
            for chunk in relevant_chunks
        ]
        
        return {
            "content": response_content,
            "confidence": 0.85,
            "sources": sources
        }
    
    def _generate_portuguese_response(self, query: str, context: str, module: Optional[str]) -> str:
        """Generate Portuguese response."""
        
        # Simulated intelligent response generation
        if module == "fccs":
            return """Com base na documentação do FCCS, posso ajudá-lo com questões de consolidação financeira. 

Para resolver problemas de consolidação:
1. Verifique se todos os dados foram carregados corretamente
2. Confirme as regras de tradução de moeda
3. Revise as eliminações intercompanhia
4. Execute o processo de consolidação

Precisa de ajuda específica com algum desses passos?"""
        
        elif module == "epbcs":
            return """Sobre o Planning and Budgeting Cloud Service (EPBCS):

Para configurar dimensões:
1. Acesse Application > Overview > Dimensions
2. Selecione a dimensão desejada
3. Configure as propriedades e hierarquias
4. Salve as alterações

Posso fornecer mais detalhes sobre configurações específicas se necessário."""
        
        else:
            return """Olá! Sou o assistente CloseWise para Oracle EPM Cloud. 

Posso ajudá-lo com:
- FCCS (Consolidação Financeira)
- EPBCS (Planejamento e Orçamento)
- Essbase (Analytics)
- ARCS (Reconciliação de Contas)
- Workforce Planning

Como posso ajudá-lo hoje?"""
    
    def _generate_english_response(self, query: str, context: str, module: Optional[str]) -> str:
        """Generate English response."""
        
        if module == "fccs":
            return """Based on FCCS documentation, I can help you with financial consolidation issues.

To resolve consolidation problems:
1. Verify all data has been loaded correctly
2. Check currency translation rules
3. Review intercompany eliminations
4. Run the consolidation process

Do you need specific help with any of these steps?"""
        
        elif module == "epbcs":
            return """Regarding Planning and Budgeting Cloud Service (EPBCS):

To configure dimensions:
1. Go to Application > Overview > Dimensions
2. Select the desired dimension
3. Configure properties and hierarchies
4. Save changes

I can provide more details about specific configurations if needed."""
        
        else:
            return """Hello! I'm the CloseWise assistant for Oracle EPM Cloud.

I can help you with:
- FCCS (Financial Consolidation)
- EPBCS (Planning and Budgeting)
- Essbase (Analytics)
- ARCS (Account Reconciliation)
- Workforce Planning

How can I assist you today?"""
    
    def process_pdf_upload(self, file_path: str, session_id: str) -> Dict[str, Any]:
        """Process uploaded PDF and add to knowledge base."""
        
        # This would extract text from PDF and process through RAG pipeline
        # For now, return simulated processing result
        
        return {
            "success": True,
            "message": "PDF processado com sucesso e adicionado à base de conhecimento",
            "pages_processed": 15,
            "chunks_created": 45,
            "module_detected": "fccs"
        }
    
    def get_knowledge_base_stats(self) -> Dict[str, Any]:
        """Get knowledge base statistics."""
        
        return {
            "total_documents": 1247,
            "total_chunks": 8934,
            "modules": {
                "fccs": 2156,
                "epbcs": 2834,
                "essbase": 1567,
                "arcs": 1234,
                "workforce": 892,
                "other": 251
            },
            "languages": {
                "portuguese": 5234,
                "english": 3700
            },
            "last_updated": "2025-06-14T10:30:00Z"
        }
    
    def get_suggested_questions(self, module: Optional[str] = None) -> List[str]:
        """Get suggested questions for the interface."""
        
        if module == "fccs":
            return [
                "Como resolver erros de tradução de moeda no FCCS?",
                "Quais são os passos para configurar eliminações?",
                "Como executar o processo de consolidação?",
                "Como configurar regras de conversão?"
            ]
        elif module == "epbcs":
            return [
                "Como criar uma nova dimensão no Planning?",
                "Como configurar formulários de entrada de dados?",
                "Como criar regras de negócio?",
                "Como configurar aprovações de workflow?"
            ]
        else:
            return [
                "Como integrar FCCS com EPBCS?",
                "Quais são as melhores práticas para backup?",
                "Como configurar segurança e permissões?",
                "Como otimizar performance do Essbase?"
            ]


def create_frontend_api_routes():
    """Create API routes for the frontend integration."""
    
    api_routes = {
        "POST /api/chat": {
            "description": "Process chat message",
            "parameters": {
                "session_id": "string",
                "message": "string",
                "language": "string (pt/en)"
            },
            "response": "ChatMessage object"
        },
        
        "POST /api/upload": {
            "description": "Upload and process PDF",
            "parameters": {
                "file": "multipart/form-data",
                "session_id": "string"
            },
            "response": "Upload result object"
        },
        
        "GET /api/knowledge-base/stats": {
            "description": "Get knowledge base statistics",
            "response": "Statistics object"
        },
        
        "GET /api/suggestions": {
            "description": "Get suggested questions",
            "parameters": {
                "module": "string (optional)"
            },
            "response": "Array of suggestion strings"
        },
        
        "GET /api/chat/history/{session_id}": {
            "description": "Get chat history for session",
            "response": "Array of ChatMessage objects"
        }
    }
    
    return api_routes


if __name__ == "__main__":
    print("CloseWise Assistant Backend Integration")
    print("Connects the frontend interface to the Apify-RAG-Pinecone pipeline")
    print("Supports Portuguese and English Oracle EPM assistance")

