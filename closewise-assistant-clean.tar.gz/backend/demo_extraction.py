"""
Example script demonstrating Apify data extraction for RAG pipeline.

This script shows how to use the ApifyExtractor to extract content from websites
and prepare it for RAG processing.
"""

import os
import json
from apify_extractor import (
    ApifyExtractor, 
    ExtractionConfig, 
    ContentValidator, 
    ContentExporter,
    create_sample_extraction_config
)


def demo_extraction_without_token():
    """
    Demonstrate the extraction process without requiring an actual Apify token.
    This creates sample data that would be typical of real extractions.
    """
    print("=== Apify Data Extraction Demo ===")
    print("Note: This demo creates sample data without requiring an Apify token.")
    print()
    
    # Sample URLs that would be used in real extraction
    sample_urls = [
        "https://docs.python.org/3/tutorial/",
        "https://fastapi.tiangolo.com/tutorial/",
        "https://docs.pinecone.io/guides/get-started/overview",
        "https://blog.apify.com/what-is-retrieval-augmented-generation/",
        "https://python.langchain.com/docs/get_started/introduction"
    ]
    
    print(f"Target URLs for extraction: {len(sample_urls)}")
    for i, url in enumerate(sample_urls, 1):
        print(f"  {i}. {url}")
    print()
    
    # Create sample extracted content (simulating real extraction results)
    sample_content = create_sample_extracted_content()
    
    print(f"Simulated extraction results: {len(sample_content)} documents")
    print()
    
    # Validate content
    validator = ContentValidator(min_word_count=50, min_title_length=5)
    valid_content = validator.filter_valid_content(sample_content)
    
    print(f"Content validation:")
    print(f"  Total items: {len(sample_content)}")
    print(f"  Valid items: {len(valid_content)}")
    print(f"  Filtered out: {len(sample_content) - len(valid_content)}")
    print()
    
    # Display sample content details
    print("Sample extracted content:")
    for i, content in enumerate(valid_content[:3], 1):
        print(f"\n  Document {i}:")
        print(f"    Title: {content.title}")
        print(f"    URL: {content.url}")
        print(f"    Type: {content.content_type}")
        print(f"    Word count: {content.word_count}")
        print(f"    Text preview: {content.text[:150]}...")
    
    if len(valid_content) > 3:
        print(f"\n  ... and {len(valid_content) - 3} more documents")
    print()
    
    # Export to files
    print("Exporting extracted content:")
    
    # Export to JSON
    json_path = "/home/ubuntu/extracted_content.json"
    ContentExporter.export_to_json(valid_content, json_path)
    
    # Export to CSV
    csv_path = "/home/ubuntu/extracted_content.csv"
    ContentExporter.export_to_csv(valid_content, csv_path)
    
    print()
    print("=== Extraction Summary ===")
    print(f"Successfully processed {len(valid_content)} documents")
    print(f"Content types found: {set(c.content_type for c in valid_content)}")
    print(f"Total words extracted: {sum(c.word_count for c in valid_content):,}")
    print(f"Average words per document: {sum(c.word_count for c in valid_content) // len(valid_content)}")
    print()
    print("Files created:")
    print(f"  - {json_path}")
    print(f"  - {csv_path}")
    print()
    print("Next steps:")
    print("  1. Review extracted content quality")
    print("  2. Configure RAG processing pipeline")
    print("  3. Generate embeddings for vector storage")
    print("  4. Store in Pinecone for retrieval")


def create_sample_extracted_content():
    """Create sample extracted content for demonstration."""
    from datetime import datetime
    from apify_extractor import ExtractedContent
    
    sample_data = [
        {
            "url": "https://docs.python.org/3/tutorial/introduction.html",
            "title": "An Informal Introduction to Python",
            "text": """Python is an easy to learn, powerful programming language. It has efficient high-level data structures and a simple but effective approach to object-oriented programming. Python's elegant syntax and dynamic typing, together with its interpreted nature, make it an ideal language for scripting and rapid application development in many areas on most platforms.

The Python interpreter and the extensive standard library are freely available in source or binary form for all major platforms from the Python Web site, https://www.python.org/, and may be freely distributed. The same site also contains distributions of and pointers to many free third-party Python modules, programs and tools, and additional documentation.

The Python interpreter is easily extended with new functions and data types implemented in C or C++ (or other languages callable from C). Python is also suitable as an extension language for customizable applications.

This tutorial introduces the reader informally to the basic concepts and features of the Python language and system. It helps to have a Python interpreter handy for hands-on experience, but all examples are self-contained, so the tutorial can be read off-line as well.""",
            "content_type": "documentation",
            "metadata": {
                "author": "Python Software Foundation",
                "language": "en",
                "description": "Introduction to Python programming language",
                "keywords": ["python", "programming", "tutorial", "documentation"]
            }
        },
        {
            "url": "https://fastapi.tiangolo.com/tutorial/first-steps/",
            "title": "First Steps with FastAPI",
            "text": """FastAPI is a modern, fast (high-performance), web framework for building APIs with Python 3.7+ based on standard Python type hints.

The key features are:
- Fast: Very high performance, on par with NodeJS and Go (thanks to Starlette and Pydantic).
- Fast to code: Increase the speed to develop features by about 200% to 300%.
- Fewer bugs: Reduce about 40% of human (developer) induced errors.
- Intuitive: Great editor support. Completion everywhere. Less time debugging.
- Easy: Designed to be easy to use and learn. Less time reading docs.
- Short: Minimize code duplication. Multiple features from each parameter declaration.
- Robust: Get production-ready code. With automatic interactive documentation.
- Standards-based: Based on (and fully compatible with) the open standards for APIs: OpenAPI and JSON Schema.

FastAPI stands on the shoulders of giants: Starlette for the web parts and Pydantic for the data parts.""",
            "content_type": "documentation",
            "metadata": {
                "author": "Sebastián Ramirez",
                "language": "en",
                "description": "FastAPI web framework tutorial",
                "keywords": ["fastapi", "python", "web", "api", "framework"]
            }
        },
        {
            "url": "https://blog.apify.com/what-is-retrieval-augmented-generation/",
            "title": "What is Retrieval-Augmented Generation (RAG)?",
            "text": """Retrieval-Augmented Generation (RAG) is a powerful technique that combines the strengths of large language models with external knowledge sources to produce more accurate, relevant, and up-to-date responses.

Traditional language models, while impressive, have limitations. They are trained on data up to a certain point in time, meaning they lack knowledge of recent events. They also can't access private or proprietary information that wasn't part of their training data.

RAG addresses these limitations by implementing a two-step process:

1. Retrieval: When a user asks a question, the system first searches through a database of relevant documents to find information that might help answer the query.

2. Generation: The retrieved information is then provided as context to a language model, which generates a response based on both its training and the retrieved information.

This approach enables AI systems to provide more accurate answers by grounding their responses in authoritative sources, while also being able to cite those sources for transparency and verification.""",
            "content_type": "article",
            "metadata": {
                "author": "Apify Team",
                "publishDate": "2024-07-10",
                "language": "en",
                "description": "Explanation of RAG technology and its applications",
                "keywords": ["rag", "retrieval", "generation", "ai", "llm"]
            }
        },
        {
            "url": "https://docs.pinecone.io/guides/get-started/overview",
            "title": "Pinecone Database Overview",
            "text": """Pinecone is a vector database that makes it easy to build high-performance vector search applications. Vector databases are purpose-built to handle the unique challenges of vector search, including high dimensionality, similarity search, and real-time updates.

Key capabilities of Pinecone include:

Serverless Architecture: Pinecone automatically scales your vector database up and down based on usage, so you only pay for what you use.

High Performance: Pinecone can handle billions of vectors with millisecond query latency, making it suitable for production applications.

Metadata Filtering: You can attach metadata to your vectors and filter search results based on this metadata, enabling more precise and relevant search results.

Hybrid Search: Combine dense and sparse vectors for more robust search capabilities that leverage both semantic similarity and keyword matching.

Real-time Updates: Add, update, or delete vectors in real-time without rebuilding your entire index.

Enterprise Security: Pinecone provides enterprise-grade security features including encryption at rest and in transit, VPC peering, and SOC 2 compliance.""",
            "content_type": "documentation",
            "metadata": {
                "author": "Pinecone Team",
                "language": "en",
                "description": "Overview of Pinecone vector database capabilities",
                "keywords": ["pinecone", "vector", "database", "search", "ai"]
            }
        },
        {
            "url": "https://python.langchain.com/docs/get_started/introduction",
            "title": "Introduction to LangChain",
            "text": """LangChain is a framework for developing applications powered by language models. It enables applications that are context-aware and can reason about their environment.

The main value propositions of LangChain are:

Components: LangChain provides modular abstractions for the components necessary to work with language models. LangChain also has collections of implementations for all these abstractions. The components are designed to be easy to use, regardless of whether you are using the rest of the LangChain framework or not.

Off-the-shelf chains: LangChain provides a number of chains for common application patterns. These chains are built using the components mentioned above and are designed to be easy to get started with.

The main areas that LangChain helps with are:
- LLM and Chat Models
- Prompt Templates
- Output Parsers
- Document Loaders
- Text Splitters
- Vector Stores
- Retrievers
- Tools and Toolkits
- Agents and Agent Executors
- Memory
- Callbacks

LangChain is particularly useful for building RAG applications, chatbots, and other AI-powered applications that need to interact with external data sources.""",
            "content_type": "documentation",
            "metadata": {
                "author": "LangChain Team",
                "language": "en",
                "description": "Introduction to LangChain framework for LLM applications",
                "keywords": ["langchain", "llm", "framework", "python", "ai"]
            }
        }
    ]
    
    # Convert to ExtractedContent objects
    extracted_content = []
    for data in sample_data:
        content = ExtractedContent(
            url=data["url"],
            title=data["title"],
            text=data["text"],
            metadata=data["metadata"],
            extraction_timestamp=datetime.now().isoformat(),
            content_type=data["content_type"],
            word_count=len(data["text"].split())
        )
        extracted_content.append(content)
    
    return extracted_content


def show_real_extraction_example():
    """Show how to use the extractor with a real Apify token."""
    print("\n=== Real Extraction Example ===")
    print("To use real Apify extraction, you would:")
    print()
    
    example_code = '''
# 1. Get an Apify token from https://console.apify.com/
apify_token = "your_actual_apify_token_here"

# 2. Create configuration
config = ExtractionConfig(
    apify_token=apify_token,
    max_pages=100,
    max_depth=3,
    include_metadata=True
)

# 3. Initialize extractor
extractor = ApifyExtractor(config)

# 4. Extract content from target URLs
urls = [
    "https://docs.python.org/3/",
    "https://fastapi.tiangolo.com/",
    "https://docs.pinecone.io/"
]

extracted_content = extractor.extract_website_content(urls)

# 5. Validate and export
validator = ContentValidator()
valid_content = validator.filter_valid_content(extracted_content)

ContentExporter.export_to_json(valid_content, "real_extracted_content.json")
'''
    
    print(example_code)
    print("This would extract real content from the specified websites.")


if __name__ == "__main__":
    # Run the demonstration
    demo_extraction_without_token()
    show_real_extraction_example()

