"""
Oracle EPM Content Ingestion Pipeline

This script creates and populates the Pinecone index with Oracle EPM content
using Apify for web scraping and OpenAI for embeddings.
"""

import os
import json
import time
from typing import List, Dict, Any
from datetime import datetime

from pinecone import Pinecone
from apify_client import ApifyClient
import openai
from api_config import config
from epm_rag_processor import EPMContentProcessor


class EPMContentIngestion:
    """Handles ingestion of Oracle EPM content into Pinecone."""
    
    def __init__(self):
        """Initialize the ingestion pipeline."""
        # Initialize clients
        self.pinecone = Pinecone(api_key=config.pinecone_api_key)
        self.apify = ApifyClient(config.apify_api_key)
        self.openai_client = openai.OpenAI(api_key=config.openai_api_key)
        
        # Get Pinecone index
        self.index = self.pinecone.Index(config.pinecone_index_name)
        
        # Initialize EPM processor
        self.epm_processor = EPMContentProcessor(config.openai_api_key)
        
        print("✅ EPM Content Ingestion Pipeline initialized")
    
    def scrape_oracle_epm_docs(self) -> List[Dict[str, Any]]:
        """Scrape Oracle EPM documentation using Apify."""
        print("🕷️ Starting Oracle EPM documentation scraping...")
        
        # Oracle EPM documentation URLs to scrape
        epm_urls = [
            "https://docs.oracle.com/en/cloud/saas/financial-consolidation-cloud/",
            "https://docs.oracle.com/en/cloud/saas/planning-budgeting-cloud/",
            "https://docs.oracle.com/en/database/other-databases/essbase/",
            "https://docs.oracle.com/en/cloud/saas/account-reconciliation-cloud/",
            "https://docs.oracle.com/en/cloud/saas/enterprise-performance-management-common/"
        ]
        
        scraped_content = []
        
        for url in epm_urls:
            try:
                print(f"Scraping: {url}")
                
                # Run the Website Content Crawler
                run_input = {
                    "startUrls": [{"url": url}],
                    "maxCrawlDepth": 2,
                    "maxCrawlPages": 50,
                    "removeCookieWarnings": True,
                    "clickElementsCssSelector": "",
                    "htmlTransformer": "readableText",
                    "readableTextCharThreshold": 100,
                    "aggressivePruning": False,
                    "debugMode": False,
                    "debugLog": False,
                    "saveHtml": False,
                    "saveMarkdown": True,
                    "saveScreenshots": False,
                    "maxScrollHeightPixels": 5000,
                    "removeElementsCssSelector": "nav, footer, .navigation, .sidebar"
                }
                
                # Start the actor run
                run = self.apify.actor("apify/website-content-crawler").call(run_input=run_input)
                
                # Fetch results
                for item in self.apify.dataset(run["defaultDatasetId"]).iterate_items():
                    if item.get("text") and len(item["text"]) > 200:
                        # Detect EPM module
                        module = self._detect_epm_module(item["url"], item["text"])
                        
                        scraped_content.append({
                            "url": item["url"],
                            "title": item.get("title", ""),
                            "text": item["text"],
                            "module": module,
                            "scraped_at": datetime.now().isoformat(),
                            "source": "oracle_docs"
                        })
                
                print(f"✅ Scraped {len(scraped_content)} documents from {url}")
                
                # Rate limiting
                time.sleep(2)
                
            except Exception as e:
                print(f"❌ Error scraping {url}: {e}")
                continue
        
        print(f"🎉 Total scraped content: {len(scraped_content)} documents")
        return scraped_content
    
    def _detect_epm_module(self, url: str, text: str) -> str:
        """Detect which EPM module the content belongs to."""
        url_lower = url.lower()
        text_lower = text.lower()
        
        if "financial-consolidation" in url_lower or "fccs" in text_lower:
            return "fccs"
        elif "planning-budgeting" in url_lower or "epbcs" in text_lower or "pbcs" in text_lower:
            return "epbcs"
        elif "essbase" in url_lower or "essbase" in text_lower:
            return "essbase"
        elif "account-reconciliation" in url_lower or "arcs" in text_lower:
            return "arcs"
        elif "workforce" in text_lower:
            return "workforce"
        elif "narrative" in text_lower:
            return "narrative"
        elif "profitability" in text_lower or "pcmcs" in text_lower:
            return "pcmcs"
        else:
            return "general"
    
    def process_and_embed_content(self, scraped_content: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Process content and generate embeddings."""
        print("🔄 Processing content and generating embeddings...")
        
        processed_chunks = []
        
        for doc in scraped_content:
            try:
                # Process document with simple chunking
                text_chunks = self._simple_chunk_text(doc["text"])
                
                chunks = []
                for chunk_text in text_chunks:
                    chunk = type('EPMChunk', (), {
                        'content': chunk_text,
                        'language': 'pt' if any(word in chunk_text.lower() for word in ['processo', 'configuração', 'dados']) else 'en',
                        'content_type': 'documentation'
                    })()
                    chunks.append(chunk)
                
                # Generate embeddings for each chunk
                for i, chunk in enumerate(chunks):
                    try:
                        # Generate embedding
                        response = self.openai_client.embeddings.create(
                            model=config.embedding_model,
                            input=chunk.content
                        )
                        
                        embedding = response.data[0].embedding
                        
                        # Create vector for Pinecone
                        vector = {
                            "id": f"{doc['module']}_{hash(doc['url'])}_{i}",
                            "values": embedding,
                            "metadata": {
                                "text": chunk.content,
                                "title": doc["title"],
                                "url": doc["url"],
                                "module": doc["module"],
                                "source": doc["source"],
                                "chunk_index": i,
                                "scraped_at": doc["scraped_at"],
                                "language": chunk.language,
                                "content_type": chunk.content_type
                            }
                        }
                        
                        processed_chunks.append(vector)
                        
                    except Exception as e:
                        print(f"❌ Error processing chunk {i} from {doc['url']}: {e}")
                        continue
                
                print(f"✅ Processed {len(chunks)} chunks from {doc['title']}")
                
            except Exception as e:
                print(f"❌ Error processing document {doc['url']}: {e}")
                continue
        
        print(f"🎉 Total processed chunks: {len(processed_chunks)}")
        return processed_chunks
    
    def _simple_chunk_text(self, text: str, chunk_size: int = 1000, overlap: int = 200) -> List[str]:
        """Simple text chunking method."""
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + chunk_size
            
            # Try to break at sentence boundary
            if end < len(text):
                # Look for sentence endings
                for i in range(end, max(start + chunk_size - 200, start), -1):
                    if text[i] in '.!?':
                        end = i + 1
                        break
            
            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
            
            start = end - overlap
            
        return chunks
    
    def upload_to_pinecone(self, vectors: List[Dict[str, Any]], batch_size: int = 100):
        """Upload vectors to Pinecone in batches."""
        print("📤 Uploading vectors to Pinecone...")
        
        total_vectors = len(vectors)
        uploaded = 0
        
        for i in range(0, total_vectors, batch_size):
            batch = vectors[i:i + batch_size]
            
            try:
                # Upload batch
                self.index.upsert(vectors=batch)
                uploaded += len(batch)
                
                print(f"✅ Uploaded batch {i//batch_size + 1}: {uploaded}/{total_vectors} vectors")
                
                # Rate limiting
                time.sleep(1)
                
            except Exception as e:
                print(f"❌ Error uploading batch {i//batch_size + 1}: {e}")
                continue
        
        print(f"🎉 Successfully uploaded {uploaded} vectors to Pinecone!")
        
        # Get final index stats
        stats = self.index.describe_index_stats()
        print(f"📊 Index stats: {stats}")
    
    def add_sample_epm_content(self):
        """Add sample EPM content for immediate testing."""
        print("📝 Adding sample EPM content...")
        
        sample_content = [
            {
                "url": "https://docs.oracle.com/fccs/sample",
                "title": "FCCS Consolidation Process Overview",
                "text": """O processo de consolidação no Oracle Financial Consolidation and Close Cloud Service (FCCS) envolve várias etapas importantes:

1. Coleta de Dados: Os dados financeiros são coletados de diferentes sistemas source
2. Tradução de Moeda: Conversão de moedas estrangeiras para a moeda de reporte
3. Eliminações Intercompanhia: Remoção de transações entre entidades do grupo
4. Ajustes de Consolidação: Aplicação de ajustes específicos de consolidação
5. Relatórios: Geração de relatórios consolidados finais

Para resolver problemas comuns de consolidação:
- Verifique se todos os dados foram carregados corretamente
- Confirme as taxas de câmbio estão atualizadas
- Revise as regras de eliminação
- Execute validações de dados antes da consolidação""",
                "module": "fccs",
                "scraped_at": datetime.now().isoformat(),
                "source": "sample_content"
            },
            {
                "url": "https://docs.oracle.com/epbcs/sample",
                "title": "EPBCS Planning Configuration Guide",
                "text": """O Oracle Enterprise Planning and Budgeting Cloud Service (EPBCS) oferece funcionalidades robustas para planejamento empresarial:

Configuração de Dimensões:
1. Acesse Application > Overview > Dimensions
2. Selecione a dimensão desejada (Account, Entity, Period, etc.)
3. Configure propriedades como Data Type, Storage, etc.
4. Defina hierarquias e relacionamentos
5. Salve as alterações

Criação de Formulários:
- Use o Form Designer para criar formulários de entrada
- Configure validações e regras de negócio
- Defina permissões de acesso por usuário/grupo
- Teste o formulário antes de publicar

Regras de Negócio:
- Utilize Calculation Manager para criar regras
- Implemente lógica de cálculo específica
- Configure triggers automáticos
- Monitore performance das regras""",
                "module": "epbcs",
                "scraped_at": datetime.now().isoformat(),
                "source": "sample_content"
            },
            {
                "url": "https://docs.oracle.com/essbase/sample",
                "title": "Essbase Performance Optimization",
                "text": """Para otimizar a performance do Oracle Essbase:

Calc Scripts:
- Revise a ordem dos cálculos para eficiência
- Use comandos FIXPARALLEL para processamento paralelo
- Implemente SET CALCPARALLEL para cálculos simultâneos
- Monitore logs de cálculo para identificar gargalos

Estrutura do Outline:
- Organize dimensões por frequência de acesso
- Coloque dimensões densas primeiro
- Use aliases para melhor usabilidade
- Implemente UDAs (User Defined Attributes) adequadamente

Cache e Memória:
- Configure Index Cache adequadamente
- Ajuste Data Cache conforme necessário
- Monitore uso de memória durante cálculos
- Use compression para economizar espaço

Manutenção:
- Execute restructure quando necessário
- Faça backup regular dos dados
- Monitore fragmentação do banco
- Implemente estratégias de archiving""",
                "module": "essbase",
                "scraped_at": datetime.now().isoformat(),
                "source": "sample_content"
            }
        ]
        
        # Process sample content
        processed_vectors = self.process_and_embed_content(sample_content)
        
        # Upload to Pinecone
        if processed_vectors:
            self.upload_to_pinecone(processed_vectors)
        
        return len(processed_vectors)
    
    def run_full_ingestion(self):
        """Run the complete ingestion pipeline."""
        print("🚀 Starting full EPM content ingestion pipeline...")
        start_time = time.time()
        
        try:
            # Step 1: Add sample content for immediate testing
            sample_count = self.add_sample_epm_content()
            print(f"✅ Added {sample_count} sample vectors")
            
            # Step 2: Scrape Oracle documentation (optional, can be time-consuming)
            print("\n📋 Would you like to scrape live Oracle EPM documentation?")
            print("This can take 10-30 minutes and use Apify credits.")
            print("Sample content is already loaded for immediate testing.")
            
            # For now, skip live scraping to save time and credits
            # Uncomment below to enable live scraping:
            
            # scraped_content = self.scrape_oracle_epm_docs()
            # if scraped_content:
            #     processed_vectors = self.process_and_embed_content(scraped_content)
            #     if processed_vectors:
            #         self.upload_to_pinecone(processed_vectors)
            
            end_time = time.time()
            duration = end_time - start_time
            
            print(f"\n🎉 Ingestion pipeline completed in {duration:.2f} seconds!")
            
            # Final stats
            stats = self.index.describe_index_stats()
            print(f"📊 Final index stats:")
            print(f"   Total vectors: {stats['total_vector_count']}")
            print(f"   Dimensions: {stats['dimension']}")
            print(f"   Namespaces: {list(stats['namespaces'].keys()) if stats['namespaces'] else ['default']}")
            
            return True
            
        except Exception as e:
            print(f"❌ Ingestion pipeline failed: {e}")
            return False


def main():
    """Main ingestion function."""
    print("CloseWise Assistant - EPM Content Ingestion")
    print("=" * 50)
    
    try:
        # Initialize ingestion pipeline
        ingestion = EPMContentIngestion()
        
        # Run ingestion
        success = ingestion.run_full_ingestion()
        
        if success:
            print("\n✅ EPM content ingestion completed successfully!")
            print("The CloseWise Assistant is now ready with Oracle EPM knowledge!")
        else:
            print("\n❌ EPM content ingestion failed")
            
    except Exception as e:
        print(f"❌ Failed to initialize ingestion pipeline: {e}")


if __name__ == "__main__":
    main()

