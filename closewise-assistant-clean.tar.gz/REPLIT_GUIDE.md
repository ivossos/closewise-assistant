# CloseWise Assistant - Replit Deployment Guide

## Quick Start on Replit

### 1. Import Project
1. Go to [Replit](https://replit.com)
2. Click "Create Repl"
3. Select "Import from GitHub"
4. Paste this repository URL
5. Click "Import from GitHub"

### 2. Configure Environment
1. In Replit, go to "Secrets" tab (🔒 icon)
2. Add the following secrets:
   ```
   OPENAI_API_KEY = your_openai_key_here
   PINECONE_API_KEY = your_pinecone_key_here
   APIFY_API_KEY = your_apify_key_here
   ```

### 3. Install Dependencies
Replit will automatically detect and install dependencies, but you can also run:
```bash
# Install Python dependencies
pip install -r requirements.txt

# Install Node.js dependencies
npm install
```

### 4. Run the Application

#### Option A: Run Both Services
1. Open two terminals in Replit
2. Terminal 1 (Backend):
   ```bash
   cd backend
   python closewise_api.py
   ```
3. Terminal 2 (Frontend):
   ```bash
   npm run dev
   ```

#### Option B: Use Replit's Run Button
1. Replit should auto-detect the project type
2. Click the "Run" button
3. It will start both frontend and backend

### 5. Access the Application
- Frontend: Usually available at the Replit webview URL
- Backend API: Available at `<replit-url>/api/`

## Replit Configuration Files

### `.replit` file (auto-created)
```toml
run = "npm run dev"
modules = ["nodejs-18", "python-3.11"]

[nix]
channel = "stable-22_11"

[deployment]
run = ["sh", "-c", "npm run build && python backend/closewise_api.py"]
```

### `replit.nix` file (auto-created)
```nix
{ pkgs }: {
  deps = [
    pkgs.nodejs-18_x
    pkgs.python311
    pkgs.python311Packages.pip
  ];
}
```

## Troubleshooting

### Common Issues

1. **Port Issues**:
   - Frontend usually runs on port 5173
   - Backend runs on port 5000
   - Replit handles port forwarding automatically

2. **Environment Variables**:
   - Make sure all API keys are set in Replit Secrets
   - Don't commit actual API keys to the repository

3. **Dependencies**:
   - If packages fail to install, try running:
     ```bash
     pip install --upgrade pip
     npm install --force
     ```

4. **CORS Issues**:
   - The backend is configured for CORS
   - If issues persist, check the CORS_ORIGINS environment variable

### Performance Tips

1. **Keep Repl Active**:
   - Replit may sleep inactive repls
   - Use the "Always On" feature for production

2. **Resource Management**:
   - Close unused terminals
   - Monitor memory usage in Replit

3. **Database Connection**:
   - Pinecone connections are managed automatically
   - Check API key validity if connection fails

## Production Deployment from Replit

1. **Export to GitHub**:
   - Use Replit's GitHub integration
   - Push changes back to repository

2. **Deploy Frontend**:
   - Connect to Vercel/Netlify from GitHub
   - Set environment variables in deployment platform

3. **Deploy Backend**:
   - Use Heroku, Railway, or similar
   - Set all environment variables
   - Update CORS origins for production URLs

## Support

If you encounter issues:
1. Check the Replit console for error messages
2. Verify all environment variables are set
3. Check the GitHub repository for updates
4. Contact support@closewise.com

---

Happy coding with CloseWise Assistant on Replit! 🚀

