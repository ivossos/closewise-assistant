import { useState, useRef, useEffect } from 'react'
import './App.css'

function App() {
  const [messages, setMessages] = useState([
    {
      id: 'welcome',
      role: 'assistant',
      content: "👋 Bem-vindo ao CloseWise\n\nSou seu assistente de IA para suporte Oracle EPM. Pergunte-me sobre FCCS, EPBCS, Essbase, Workforce Planning e muito mais!",
      timestamp: new Date().toISOString(),
      module: null
    }
  ])
  const [inputMessage, setInputMessage] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [activeTab, setActiveTab] = useState('chat')
  const messagesEndRef = useRef(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const epmModules = [
    {
      id: 'fccs',
      title: 'FCCS Consolidation Issues',
      description: 'Get help with elimination rules, intercompany matching, and close processes',
      color: 'bg-blue-50 border-blue-200'
    },
    {
      id: 'epbcs',
      title: 'EPBCS Planning Problems',
      description: 'Resolve calculation errors, form issues, and approval workflows',
      color: 'bg-green-50 border-green-200'
    },
    {
      id: 'essbase',
      title: 'Essbase Performance',
      description: 'Optimize calculation scripts, database structure, and processing speed',
      color: 'bg-yellow-50 border-yellow-200'
    },
    {
      id: 'workforce',
      title: 'Workforce Planning',
      description: 'Configure salary forecasts, headcount models, and benefit calculations',
      color: 'bg-purple-50 border-purple-200'
    }
  ]

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return

    const userMessage = {
      id: `user_${Date.now()}`,
      role: 'user',
      content: inputMessage,
      timestamp: new Date().toISOString()
    }

    setMessages(prev => [...prev, userMessage])
    setInputMessage('')
    setIsTyping(true)

    // Simulate API call to backend
    setTimeout(() => {
      const assistantResponse = generateResponse(inputMessage)
      setMessages(prev => [...prev, assistantResponse])
      setIsTyping(false)
    }, 1500)
  }

  const generateResponse = (userInput) => {
    const input = userInput.toLowerCase()
    
    let response = {
      id: `assistant_${Date.now()}`,
      role: 'assistant',
      timestamp: new Date().toISOString(),
      confidence: 0.85,
      sources: []
    }

    if (input.includes('fccs') || input.includes('consolidation') || input.includes('consolidação')) {
      response.content = `Com base na documentação do FCCS, posso ajudá-lo com questões de consolidação financeira.

Para resolver problemas de consolidação:
1. Verifique se todos os dados foram carregados corretamente
2. Confirme as regras de tradução de moeda
3. Revise as eliminações intercompanhia
4. Execute o processo de consolidação

Precisa de ajuda específica com algum desses passos?`
      response.module = 'fccs'
      response.sources = [
        {
          title: 'FCCS Consolidation Process Guide',
          url: 'https://docs.oracle.com/en/cloud/saas/financial-consolidation-cloud/',
          confidence: 0.92
        }
      ]
    } else if (input.includes('planning') || input.includes('epbcs') || input.includes('planejamento')) {
      response.content = `Sobre o Planning and Budgeting Cloud Service (EPBCS):

Para configurar dimensões:
1. Acesse Application > Overview > Dimensions
2. Selecione a dimensão desejada
3. Configure as propriedades e hierarquias
4. Salve as alterações

Posso fornecer mais detalhes sobre configurações específicas se necessário.`
      response.module = 'epbcs'
      response.sources = [
        {
          title: 'Planning Dimension Configuration',
          url: 'https://docs.oracle.com/en/cloud/saas/planning-budgeting-cloud/',
          confidence: 0.87
        }
      ]
    } else if (input.includes('essbase') || input.includes('performance') || input.includes('cálculo')) {
      response.content = `Para otimizar performance do Essbase:

1. **Calc Scripts**: Revise a ordem dos cálculos
2. **Outline**: Otimize a estrutura das dimensões
3. **Cache**: Configure adequadamente o cache
4. **Parallel Processing**: Use processamento paralelo quando possível

Qual aspecto específico você gostaria de melhorar?`
      response.module = 'essbase'
      response.sources = [
        {
          title: 'Essbase Performance Tuning Guide',
          url: 'https://docs.oracle.com/en/database/other-databases/essbase/',
          confidence: 0.89
        }
      ]
    } else {
      response.content = `Olá! Sou o assistente CloseWise para Oracle EPM Cloud.

Posso ajudá-lo com:
- **FCCS** (Consolidação Financeira)
- **EPBCS** (Planejamento e Orçamento)
- **Essbase** (Analytics)
- **ARCS** (Reconciliação de Contas)
- **Workforce Planning**

Como posso ajudá-lo hoje?`
      response.module = null
    }

    return response
  }

  const handleModuleClick = (moduleId) => {
    const moduleQuestions = {
      fccs: "Como resolver erros de tradução de moeda no FCCS?",
      epbcs: "Como criar uma nova dimensão no Planning?",
      essbase: "Como otimizar performance dos calc scripts?",
      workforce: "Como configurar modelos de previsão salarial?"
    }
    
    setInputMessage(moduleQuestions[moduleId] || "")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-700 to-indigo-800">
      <div className="container mx-auto p-4 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center shadow-lg">
              <span className="text-2xl font-bold text-purple-600">CW</span>
            </div>
            <h1 className="text-4xl font-bold text-white">CloseWise Assistant</h1>
          </div>
          <p className="text-purple-100 text-lg">AI-powered Oracle EPM support specialist</p>
        </div>

        {/* Main Interface */}
        <div className="bg-white rounded-lg shadow-xl overflow-hidden">
          <div className="p-6">
            <div className="flex gap-4 mb-6">
              <button 
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  activeTab === 'chat' 
                    ? 'bg-purple-600 text-white shadow-md' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
                onClick={() => setActiveTab('chat')}
              >
                💬 Chat
              </button>
              <button 
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  activeTab === 'upload' 
                    ? 'bg-purple-600 text-white shadow-md' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
                onClick={() => setActiveTab('upload')}
              >
                📄 Upload PDFs
              </button>
              <button 
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  activeTab === 'knowledge' 
                    ? 'bg-purple-600 text-white shadow-md' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
                onClick={() => setActiveTab('knowledge')}
              >
                🗄️ Knowledge Base
              </button>
            </div>

            {activeTab === 'chat' && (
              <div className="space-y-4">
                {/* Chat Messages */}
                <div className="h-96 w-full border border-gray-200 rounded-lg p-4 overflow-y-auto bg-gray-50">
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div key={message.id} className={`flex ${
                        message.role === 'user' ? 'justify-end' : 'justify-start'
                      }`}>
                        <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                          message.role === 'user' 
                            ? 'bg-purple-600 text-white' 
                            : 'bg-white border border-gray-200 shadow-sm'
                        }`}>
                          <div className="whitespace-pre-wrap text-sm">{message.content}</div>
                          
                          {message.module && (
                            <span className="inline-block mt-2 px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded">
                              {message.module.toUpperCase()}
                            </span>
                          )}
                          
                          {message.confidence && (
                            <div className="mt-2">
                              <div className="text-xs text-gray-500 mb-1">
                                Confidence: {Math.round(message.confidence * 100)}%
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-1">
                                <div 
                                  className="bg-purple-600 h-1 rounded-full transition-all duration-300" 
                                  style={{ width: `${message.confidence * 100}%` }}
                                />
                              </div>
                            </div>
                          )}
                          
                          {message.sources && message.sources.length > 0 && (
                            <div className="mt-3 space-y-1">
                              <div className="text-xs font-medium text-gray-600">Sources:</div>
                              {message.sources.map((source, idx) => (
                                <div key={idx} className="p-2 border border-gray-100 rounded text-xs bg-gray-50">
                                  <div className="flex items-center justify-between">
                                    <span className="font-medium">{source.title}</span>
                                    <span>🔗</span>
                                  </div>
                                  <div className="text-gray-500">
                                    Confidence: {Math.round(source.confidence * 100)}%
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                    
                    {isTyping && (
                      <div className="flex justify-start">
                        <div className="bg-white border border-gray-200 shadow-sm px-4 py-3 rounded-lg">
                          <div className="flex items-center gap-2">
                            <span className="text-sm text-gray-600">CloseWise está digitando</span>
                            <div className="flex gap-1">
                              <div className="w-2 h-2 bg-purple-600 rounded-full animate-bounce"></div>
                              <div className="w-2 h-2 bg-purple-600 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                              <div className="w-2 h-2 bg-purple-600 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <div ref={messagesEndRef} />
                  </div>
                </div>

                {/* Chat Input */}
                <div className="flex gap-2">
                  <input
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    placeholder="Describe your Oracle EPM issue... (Shift+Enter for new line)"
                    className="flex-1 p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault()
                        handleSendMessage()
                      }
                    }}
                  />
                  <button 
                    onClick={handleSendMessage}
                    className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    disabled={!inputMessage.trim() || isTyping}
                  >
                    ➤
                  </button>
                </div>

                {/* Welcome Message and Module Cards */}
                {messages.length === 1 && (
                  <div className="mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {epmModules.map((module) => (
                        <div 
                          key={module.id}
                          className={`p-4 border-2 rounded-lg cursor-pointer hover:shadow-md transition-all duration-200 ${module.color} hover:scale-105`}
                          onClick={() => handleModuleClick(module.id)}
                        >
                          <h3 className="font-semibold text-gray-800 mb-1">
                            {module.title}
                          </h3>
                          <p className="text-sm text-gray-600">
                            {module.description}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'upload' && (
              <div className="text-center py-12">
                <div className="text-6xl mb-4">📄</div>
                <h3 className="text-lg font-semibold mb-2">Upload PDF Documents</h3>
                <p className="text-gray-600 mb-4">
                  Add Oracle EPM documentation to enhance the knowledge base
                </p>
                <button className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                  Select Files
                </button>
              </div>
            )}

            {activeTab === 'knowledge' && (
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="text-lg font-semibold mb-4">Knowledge Base Statistics</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="text-2xl font-bold text-blue-600">4</div>
                      <div className="text-sm text-gray-600">Documents</div>
                    </div>
                    <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                      <div className="text-2xl font-bold text-green-600">3</div>
                      <div className="text-sm text-gray-600">EPM Modules</div>
                    </div>
                    <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                      <div className="text-2xl font-bold text-purple-600">100%</div>
                      <div className="text-sm text-gray-600">Operational</div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-8 text-purple-100">
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
              <span className="text-lg font-bold text-purple-600">CW</span>
            </div>
            <span className="font-semibold">CloseWise</span>
          </div>
          <p className="text-sm">© 2025 CloseWise. AI-powered Oracle EPM Support Assistant</p>
          <p className="text-xs mt-1 opacity-75">support@closewise.com | www.closewise.com</p>
        </div>
      </div>
    </div>
  )
}

export default App

